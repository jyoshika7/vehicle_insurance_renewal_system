<?php
session_start();

$currentAgentId = $_SESSION['agent_id'] ?? null;

if ($currentAgentId !== null && isset($_SESSION['logged_agents']) && is_array($_SESSION['logged_agents'])) {
    unset($_SESSION['logged_agents'][$currentAgentId]);

    $remainingAgents = array_keys($_SESSION['logged_agents']);

    if (!empty($remainingAgents)) {
        $nextAgentId = (int) $remainingAgents[0];
        $_SESSION['agent_id'] = $nextAgentId;
        $_SESSION['agent_name'] = $_SESSION['logged_agents'][$nextAgentId]['name'];
    } else {
        session_unset();
        session_destroy();
    }
} else {
    session_unset();
    session_destroy();
}

header("Location: ../login.php");
exit();
?>