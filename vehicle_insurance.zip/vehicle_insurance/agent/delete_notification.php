<?php
session_start();
include("../config/db.php");

if (!isset($_SESSION['agent_id'])) {
    header("Location: ../login.php");
    exit();
}

if (!isset($_GET['id'])) {
    header("Location: notification.php");
    exit();
}

$agentId = (int) $_SESSION['agent_id'];
$notification_id = (int)$_GET['id'];

/* Check whether the notification exists and belongs to this agent */
$check = mysqli_query($conn, "SELECT * FROM notifications WHERE notification_id='$notification_id' AND agent_id='$agentId'");

if (mysqli_num_rows($check) == 0) {
    echo "<script>
            alert('Notification not found.');
            window.location='notification.php';
          </script>";
    exit();
}

/*
|--------------------------------------------------------------------------
| Delete Notification
|--------------------------------------------------------------------------
*/

$delete = mysqli_query($conn, "
DELETE FROM notifications
WHERE notification_id='$notification_id' AND agent_id='$agentId'
");

if($delete)
{
    echo "<script>
    alert('Notification deleted successfully.');
    window.location='notification.php';
    </script>";
}
else
{
    echo "<script>
    alert('Unable to delete notification.');
    window.location='notification.php';
    </script>";
}
?>
