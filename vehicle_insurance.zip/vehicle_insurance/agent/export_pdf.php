<?php
session_start();
include("../config/db.php");

require("fpdf/fpdf.php");

if (!isset($_SESSION['agent_id'])) {
    header("Location: ../login.php");
    exit();
}

$pdf = new FPDF('L', 'mm', 'A4');
$pdf->AddPage();

$pdf->SetFont('Arial','B',16);
$pdf->Cell(0,10,'Vehicle Insurance Report',0,1,'C');

$pdf->Ln(5);

$pdf->SetFont('Arial','B',10);

$pdf->Cell(45,10,'Customer',1);
$pdf->Cell(35,10,'Vehicle No',1);
$pdf->Cell(25,10,'Type',1);
$pdf->Cell(45,10,'Company',1);
$pdf->Cell(35,10,'Policy No',1);
$pdf->Cell(25,10,'Premium',1);
$pdf->Cell(35,10,'Expiry',1);
$pdf->Cell(30,10,'Status',1);

$pdf->Ln();

$agentId = (int) $_SESSION['agent_id'];
$today = date("Y-m-d");
$warning = date("Y-m-d", strtotime("+30 days"));

$sql = mysqli_query($conn,"
SELECT
v.*,
c.customer_name
FROM vehicles v
JOIN customers c
ON v.customer_id = c.customer_id
WHERE v.agent_id='$agentId' AND c.agent_id='$agentId'
ORDER BY v.policy_expiry ASC
");

$pdf->SetFont('Arial','',9);

while($row = mysqli_fetch_assoc($sql))
{

    if($row['policy_expiry'] < $today)
        $status = "Expired";
    elseif($row['policy_expiry'] <= $warning)
        $status = "Expiring Soon";
    else
        $status = "Active";

    $pdf->Cell(45,8,$row['customer_name'],1);
    $pdf->Cell(35,8,$row['vehicle_number'],1);
    $pdf->Cell(25,8,$row['vehicle_type'],1);
    $pdf->Cell(45,8,$row['insurance_company'],1);
    $pdf->Cell(35,8,$row['policy_number'],1);
    $pdf->Cell(25,8,number_format($row['premium_amount'],2),1);
    $pdf->Cell(35,8,date("d-m-Y",strtotime($row['policy_expiry'])),1);
    $pdf->Cell(30,8,$status,1);

    $pdf->Ln();
}

$pdf->Output("I","Vehicle_Insurance_Report.pdf");
exit();