<?php
session_start();
include("../config/db.php");

if (!isset($_SESSION['agent_id'])) {
    header("Location: ../login.php");
    exit();
}

if (!isset($_GET['id'])) {
    header("Location: vehicles.php");
    exit();
}

$agentId = (int) $_SESSION['agent_id'];
$id = (int)$_GET['id'];

// Check if the vehicle exists
$check = mysqli_query($conn, "SELECT vehicle_id FROM vehicles WHERE vehicle_id='$id' AND agent_id='$agentId'");

if (mysqli_num_rows($check) == 0) {
    echo "<script>
            alert('Vehicle not found.');
            window.location='vehicles.php';
          </script>";
    exit();
}

// Delete the vehicle
$delete = mysqli_query($conn, "DELETE FROM vehicles WHERE vehicle_id='$id' AND agent_id='$agentId'");

if ($delete) {
    echo "<script>
            alert('Vehicle deleted successfully.');
            window.location='vehicles.php';
          </script>";
} else {
    echo "<script>
            alert('Unable to delete vehicle.');
            window.location='vehicles.php';
          </script>";
}
?>