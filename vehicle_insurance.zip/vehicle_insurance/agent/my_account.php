<?php
session_start();
include("../config/db.php");

if (!isset($_SESSION['agent_id'])) {
    header("Location: ../login.php");
    exit();
}

$agentId = (int) $_SESSION['agent_id'];
$error = "";
$success = "";

$currentAgent = mysqli_fetch_assoc(
    mysqli_query($conn, "SELECT * FROM agents WHERE agent_id='$agentId'")
);

if (!$currentAgent) {
    session_unset();
    session_destroy();
    header("Location: ../login.php");
    exit();
}

if (isset($_POST['update_profile'])) {
    $name = trim($_POST['name']);
    $username = trim($_POST['username']);
    $password = $_POST['password'];
    $confirmPassword = $_POST['confirm_password'];

    if (empty($name) || empty($username)) {
        $error = "Name and username are required.";
    } else {
        $check = mysqli_query($conn, "SELECT * FROM agents WHERE username='$username' AND agent_id != '$agentId'");

        if (mysqli_num_rows($check) > 0) {
            $error = "This username is already used by another agent.";
        } else {
            $updateQuery = "UPDATE agents SET name='$name', username='$username'";

            if (!empty($password)) {
                if ($password !== $confirmPassword) {
                    $error = "Passwords do not match.";
                } else {
                    $updateQuery .= ", password='$password'";
                }
            } elseif (!empty($confirmPassword)) {
                $error = "Password confirmation does not match the current password field.";
            }

            if ($error === "") {
                $updateQuery .= " WHERE agent_id='$agentId'";

                if (mysqli_query($conn, $updateQuery)) {
                    $_SESSION['agent_name'] = $name;
                    $_SESSION['logged_agents'][$agentId]['name'] = $name;
                    $_SESSION['logged_agents'][$agentId]['username'] = $username;

                    $success = "Profile updated successfully.";
                    $currentAgent['name'] = $name;
                    $currentAgent['username'] = $username;
                } else {
                    $error = "Unable to update profile.";
                }
            }
        }
    }
}
?>

<?php include("../includes/header.php"); ?>
<?php include("../includes/sidebar.php"); ?>

<div class="content">
    <div class="container-fluid">
        <div class="card shadow">
            <div class="card-header bg-primary text-white">
                <h3><i class="fa-solid fa-user"></i> My Account</h3>
            </div>

            <div class="card-body">
                <?php if ($error != "") { ?>
                    <div class="alert alert-danger"><?php echo htmlspecialchars($error); ?></div>
                <?php } ?>

                <?php if ($success != "") { ?>
                    <div class="alert alert-success"><?php echo htmlspecialchars($success); ?></div>
                <?php } ?>

                <form method="POST">
                    <div class="row">
                        <div class="col-md-6 mb-3">
                            <label class="form-label">Full Name</label>
                            <input type="text" name="name" class="form-control" value="<?php echo htmlspecialchars($currentAgent['name']); ?>" required>
                        </div>

                        <div class="col-md-6 mb-3">
                            <label class="form-label">Username</label>
                            <input type="text" name="username" class="form-control" value="<?php echo htmlspecialchars($currentAgent['username']); ?>" required>
                        </div>

                        <div class="col-md-6 mb-3">
                            <label class="form-label">New Password</label>
                            <input type="password" name="password" class="form-control" placeholder="Leave blank to keep current password">
                        </div>

                        <div class="col-md-6 mb-3">
                            <label class="form-label">Confirm New Password</label>
                            <input type="password" name="confirm_password" class="form-control" placeholder="Leave blank to keep current password">
                        </div>
                    </div>

                    <div class="d-flex gap-2">
                        <button type="submit" name="update_profile" class="btn btn-primary">
                            <i class="fa-solid fa-floppy-disk"></i> Save Changes
                        </button>
                        <a href="logout.php" class="btn btn-outline-danger" onclick="return confirm('Log out this agent account?');">
                            <i class="fa-solid fa-right-from-bracket"></i> Logout
                        </a>
                    </div>
                </form>
            </div>
        </div>
    </div>
</div>

<?php include("../includes/footer.php"); ?>
