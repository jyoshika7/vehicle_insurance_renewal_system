<?php
session_start();
include("../config/db.php");
include("../config/mail.php");

if (!isset($_SESSION['agent_id'])) {
    header("Location: ../login.php");
    exit();
}

if (!isset($_GET['id'])) {
    header("Location: renewals.php");
    exit();
}

$agentId = (int) $_SESSION['agent_id'];
$id = (int)$_GET['id'];

$sql = mysqli_query($conn,"
SELECT
    v.*,
    c.customer_name,
    c.email
FROM vehicles v
JOIN customers c
ON v.customer_id = c.customer_id
WHERE v.vehicle_id='$id' AND v.agent_id='$agentId' AND c.agent_id='$agentId'
");







if(mysqli_num_rows($sql)==0)
{
    echo "<script>
    alert('Vehicle not found');
    window.location='renewals.php';
    </script>";
    exit();
}

$row = mysqli_fetch_assoc($sql);

if (isset($_POST['renew'])) {
    $policy_expiry = trim($_POST['policy_expiry']);
    $expiry_timestamp = strtotime($policy_expiry);
    $new_expiry = $expiry_timestamp ? date('Y-m-d', $expiry_timestamp) : null;
    $renewal_date = date('Y-m-d');

    if (!$expiry_timestamp) {
        echo "<script>
        alert('Please enter a valid expiry date.');
        window.location='renew_policy.php?id=$id';
        </script>";
        exit();
    }

    $query = "UPDATE vehicles SET
        policy_expiry='$new_expiry',
        renewal_date='$renewal_date',
        renewed='Yes',
        status='Active'
        WHERE vehicle_id='$id' AND agent_id='$agentId'";

    if (mysqli_query($conn, $query)) {
        $mailSent = sendRenewalMail(
            $row['email'],
            $row['customer_name'],
            $row['vehicle_number'],
            $row['vehicle_type'],
            $row['vehicle_model'],
            $row['insurance_company'],
            $row['policy_number'],
            $row['premium_amount'],
            date('d-m-Y'),
            date('d-m-Y', $expiry_timestamp)
        );

        $status = $mailSent ? 'Sent' : 'Failed';
        $subject = 'Vehicle Insurance Policy Renewed';
        $message = "Dear {$row['customer_name']},\n\n"
            . "Your vehicle insurance policy has been renewed successfully.\n\n"
            . "Vehicle Number : {$row['vehicle_number']}\n"
            . "Insurance Company : {$row['insurance_company']}\n"
            . "Premium Amount : ₹" . number_format($row['premium_amount'], 2) . "\n"
            . "Renewal Date : " . date('d-m-Y') . "\n"
            . "New Expiry Date : " . date('d-m-Y', $expiry_timestamp) . "\n\n"
            . "Thank you for choosing our insurance service.";

        $vehicle_id = mysqli_real_escape_string($conn, $row['vehicle_id']);
        $customer_name = mysqli_real_escape_string($conn, $row['customer_name']);
        $email = mysqli_real_escape_string($conn, $row['email']);
        $subject_escaped = mysqli_real_escape_string($conn, $subject);
        $message_escaped = mysqli_real_escape_string($conn, $message);
        $status_escaped = mysqli_real_escape_string($conn, $status);
        $sent_date = date('Y-m-d H:i:s');

        mysqli_query($conn, "
            INSERT INTO notifications
            (agent_id, vehicle_id, customer_name, email, subject, message, status, sent_date)
            VALUES
            ('$agentId', '$vehicle_id', '$customer_name', '$email', '$subject_escaped', '$message_escaped', '$status_escaped', '$sent_date')
        ");

        echo "<script>
        alert('Policy renewed successfully. Email notification sent to customer.');
        window.location='renewals.php';
        </script>";
        exit();
    } else {
        echo "<script>
        alert('Failed to renew policy. Please try again.');
        window.location='renewals.php';
        </script>";
        exit();
    }
}
?>

<?php include("../includes/header.php"); ?>
<?php include("../includes/sidebar.php"); ?>

<div class="content">

<div class="container-fluid">

<div class="card shadow">

<div class="card-header bg-warning">

<h3>

<i class="fa-solid fa-rotate"></i>

Renew Insurance Policy

</h3>

</div>

<div class="card-body">

<form method="POST">

<div class="row">
<div class="col-md-6 mb-3">

<label class="form-label">
Customer Name
</label>

<input
type="text"
class="form-control"
value="<?php echo htmlspecialchars($row['customer_name']); ?>"
readonly>

</div>

<div class="col-md-6 mb-3">

<label class="form-label">
Vehicle Number
</label>

<input
type="text"
class="form-control"
value="<?php echo htmlspecialchars($row['vehicle_number']); ?>"
readonly>

</div>

<div class="col-md-6 mb-3">

<label class="form-label">
Vehicle Type
</label>

<input
type="text"
class="form-control"
value="<?php echo htmlspecialchars($row['vehicle_type']); ?>"
readonly>

</div>

<div class="col-md-6 mb-3">

<label class="form-label">
Insurance Company
</label>

<input
type="text"
class="form-control"
value="<?php echo htmlspecialchars($row['insurance_company']); ?>"
readonly>

</div>

<div class="col-md-6 mb-3">

<label class="form-label">
Policy Number
</label>

<input
type="text"
class="form-control"
value="<?php echo htmlspecialchars($row['policy_number']); ?>"
readonly>

</div>

<div class="col-md-6 mb-3">

<label class="form-label">
Premium Amount
</label>

<input
type="text"
class="form-control"
value="₹ <?php echo number_format($row['premium_amount'],2); ?>"
readonly>

</div>
<div class="col-md-6 mb-3">

<label class="form-label">
Current Expiry Date
</label>

<input
type="text"
class="form-control"
value="<?php echo date('d-m-Y',strtotime($row['policy_expiry'])); ?>"
readonly>

</div>

<div class="col-md-6 mb-3">

<label class="form-label">
New Policy Expiry Date
</label>

<input
type="date"
name="policy_expiry"
class="form-control"
required>

</div>

</div>

<hr>

<div class="d-flex gap-2">

<button
type="submit"
name="renew"
class="btn btn-success">

<i class="fa-solid fa-rotate"></i>

Renew Policy

</button>

<a
href="renewals.php"
class="btn btn-secondary">

<i class="fa-solid fa-arrow-left"></i>

Back

</a>

</div>

</form>

</div>

</div>

</div>

</div>

<?php include("../includes/footer.php"); ?>