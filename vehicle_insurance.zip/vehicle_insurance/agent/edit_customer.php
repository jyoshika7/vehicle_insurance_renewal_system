<?php
session_start();
include("../config/db.php");

if (!isset($_SESSION['agent_id'])) {
    header("Location: ../login.php");
    exit();
}

if (!isset($_GET['id'])) {
    header("Location: customers.php");
    exit();
}

$agentId = (int) $_SESSION['agent_id'];
$id = (int)$_GET['id'];

$result = mysqli_query($conn, "SELECT * FROM customers WHERE customer_id='$id' AND agent_id='$agentId'");

if (mysqli_num_rows($result) == 0) {
    echo "<script>
            alert('Customer not found');
            window.location='customers.php';
          </script>";
    exit();
}

$customer = mysqli_fetch_assoc($result);

if(isset($_POST['update']))
{
    $customer_name = trim($_POST['customer_name']);
    $phone = trim($_POST['phone']);
    $email = trim($_POST['email']);
    $address = trim($_POST['address']);

    $update = mysqli_query($conn,"
        UPDATE customers SET
        customer_name='$customer_name',
        phone='$phone',
        email='$email',
        address='$address'
        WHERE customer_id='$id' AND agent_id='$agentId'
    ");

    if($update)
    {
        echo "<script>
            alert('Customer Updated Successfully');
            window.location='customers.php';
        </script>";
        exit();
    }
}
?>

<?php include("../includes/header.php"); ?>
<?php include("../includes/sidebar.php"); ?>

<div class="content">
<div class="container-fluid">

<div class="card shadow">

<div class="card-header bg-primary text-white">

<h3>
<i class="fa-solid fa-user-pen"></i>
Edit Customer
</h3>

</div>

<div class="card-body">

<form method="POST">

<div class="row">
<div class="col-md-6 mb-3">

<label class="form-label">
Customer Name
</label>

<input
type="text"
name="customer_name"
class="form-control"
value="<?php echo htmlspecialchars($customer['customer_name']); ?>"
required>

</div>

<div class="col-md-6 mb-3">

<label class="form-label">
Phone Number
</label>

<input
type="text"
name="phone"
class="form-control"
maxlength="10"
value="<?php echo htmlspecialchars($customer['phone']); ?>"
required>

</div>

<div class="col-md-6 mb-3">

<label class="form-label">
Email Address
</label>

<input
type="email"
name="email"
class="form-control"
value="<?php echo htmlspecialchars($customer['email']); ?>">

</div>

<div class="col-md-12 mb-3">

<label class="form-label">
Address
</label>

<textarea
name="address"
class="form-control"
rows="4"
required><?php echo htmlspecialchars($customer['address']); ?></textarea>

</div>
</div>

<hr>

<div class="d-flex gap-2">

<button
type="submit"
name="update"
class="btn btn-primary">

<i class="fa-solid fa-floppy-disk"></i>

Update Customer

</button>

<a
href="customers.php"
class="btn btn-secondary">

<i class="fa-solid fa-arrow-left"></i>

Back

</a>

<button
type="reset"
class="btn btn-warning">

<i class="fa-solid fa-rotate"></i>

Reset

</button>

</div>

</form>

</div>

</div>

</div>

</div>

<?php include("../includes/footer.php"); ?>