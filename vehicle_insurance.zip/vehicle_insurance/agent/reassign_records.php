<?php
session_start();
include("../config/db.php");

if (!isset($_SESSION['agent_id'])) {
    header("Location: ../login.php");
    exit();
}

$agentId = (int) $_SESSION['agent_id'];

if (isset($_POST['reassign'])) {
    $targetAgentId = (int) $_POST['target_agent_id'];

    if ($targetAgentId <= 0) {
        $error = "Please select a valid agent.";
    } else {
        $customerCount = mysqli_query($conn, "UPDATE customers SET agent_id='$targetAgentId' WHERE agent_id='$agentId'");
        $vehicleCount = mysqli_query($conn, "UPDATE vehicles SET agent_id='$targetAgentId' WHERE agent_id='$agentId'");
        $notificationCount = mysqli_query($conn, "UPDATE notifications SET agent_id='$targetAgentId' WHERE agent_id='$agentId'");

        $success = "Assigned all records from this account to the selected agent.";
    }
}

$agents = mysqli_query($conn, "SELECT agent_id, name, username FROM agents WHERE agent_id != '$agentId' ORDER BY name");
?>

<?php include("../includes/header.php"); ?>
<?php include("../includes/sidebar.php"); ?>

<div class="content">
    <div class="container-fluid">
        <div class="card shadow">
            <div class="card-header bg-warning text-dark">
                <h3><i class="fa-solid fa-arrow-right-arrow-left"></i> Reassign Records</h3>
            </div>

            <div class="card-body">
                <?php if (isset($error)) { ?>
                    <div class="alert alert-danger"><?php echo htmlspecialchars($error); ?></div>
                <?php } ?>

                <?php if (isset($success)) { ?>
                    <div class="alert alert-success"><?php echo htmlspecialchars($success); ?></div>
                <?php } ?>

                <p class="text-muted">Transfer this agent’s customers, vehicles, and notifications to another agent.</p>

                <form method="POST">
                    <div class="mb-3">
                        <label class="form-label">Select Agent</label>
                        <select name="target_agent_id" class="form-select" required>
                            <option value="">Choose an agent</option>
                            <?php while ($row = mysqli_fetch_assoc($agents)) { ?>
                                <option value="<?php echo $row['agent_id']; ?>"><?php echo htmlspecialchars($row['name']); ?> (<?php echo htmlspecialchars($row['username']); ?>)</option>
                            <?php } ?>
                        </select>
                    </div>

                    <button type="submit" name="reassign" class="btn btn-warning">
                        <i class="fa-solid fa-arrow-right-arrow-left"></i> Reassign Records
                    </button>
                </form>
            </div>
        </div>
    </div>
</div>

<?php include("../includes/footer.php"); ?>
