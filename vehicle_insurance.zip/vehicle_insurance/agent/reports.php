<?php
session_start();
include("../config/db.php");

if (!isset($_SESSION['agent_id'])) {
    header("Location: ../login.php");
    exit();
}

$today = date("Y-m-d");
$warning = date("Y-m-d", strtotime("+30 days"));

$agentId = (int) $_SESSION['agent_id'];
$company = isset($_GET['company']) ? mysqli_real_escape_string($conn, $_GET['company']) : "";
$type    = isset($_GET['type']) ? mysqli_real_escape_string($conn, $_GET['type']) : "";
$status  = isset($_GET['status']) ? $_GET['status'] : "";

$sql = "
SELECT
v.*,
c.customer_name
FROM vehicles v
JOIN customers c
ON v.customer_id = c.customer_id
WHERE v.agent_id='$agentId' AND c.agent_id='$agentId'
";

if($company != "")
{
    $sql .= " AND v.insurance_company='$company'";
}

if($type != "")
{
    $sql .= " AND v.vehicle_type='$type'";
}

$result = mysqli_query($conn,$sql);
?>

<?php include("../includes/header.php"); ?>
<?php include("../includes/sidebar.php"); ?>

<style media="print">
    @page {
        margin: 12mm;
    }

    .sidebar,
    .report-actions,
    .report-filters,
    .btn {
        display: none !important;
    }

    body {
        background: #fff !important;
    }

    .content {
        margin: 0 !important;
        padding: 0 !important;
        width: 100% !important;
    }

    .report-header {
        margin-bottom: 12px !important;
    }

    .report-output,
    .report-output .card-header,
    .report-output .card-body {
        border: 0 !important;
        box-shadow: none !important;
        background: #fff !important;
    }

    .report-output .table {
        width: 100% !important;
        color: #000 !important;
    }

    .report-output .table th {
        background: #e5e7eb !important;
        color: #000 !important;
    }
</style>

<div class="content">

<div class="container-fluid">

<div class="d-flex justify-content-between align-items-center mb-4 report-header">

<h2>
<i class="fa-solid fa-chart-column"></i>
Insurance Reports
</h2>

<div class="report-actions">

<a href="export_pdf.php" class="btn btn-danger">
<i class="fa-solid fa-file-pdf"></i>
PDF
</a>

<a href="export_excel.php" class="btn btn-success">
<i class="fa-solid fa-file-excel"></i>
Excel
</a>

<button onclick="window.print()" class="btn btn-primary">
<i class="fa-solid fa-print"></i>
Print
</button>

</div>

</div>

<div class="card shadow mb-4 report-filters">

    <div class="card-header bg-success text-white">

        <h5 class="mb-0">
            Filter Reports
        </h5>

    </div>

    <div class="card-body">

        <form method="GET">

            <div class="row">

                <div class="col-md-4">

                    <label class="form-label">Insurance Company</label>

                    <select name="company" class="form-select">

                        <option value="">All Companies</option>

                        <?php

                        $companies = mysqli_query($conn,"
                        SELECT DISTINCT insurance_company
                        FROM vehicles
                        WHERE agent_id='$agentId'
                        ORDER BY insurance_company
                        ");

                        while($c = mysqli_fetch_assoc($companies))
                        {
                        ?>

                        <option
                        value="<?php echo $c['insurance_company']; ?>"
                        <?php if($company == $c['insurance_company']) echo "selected"; ?>>

                        <?php echo $c['insurance_company']; ?>

                        </option>

                        <?php } ?>

                    </select>

                </div>

                <div class="col-md-4">

                    <label class="form-label">Vehicle Type</label>

                    <select name="type" class="form-select">

                        <option value="">All Types</option>

                        <?php

                        $types = mysqli_query($conn,"
                        SELECT DISTINCT vehicle_type
                        FROM vehicles
                        WHERE agent_id='$agentId'
                        ORDER BY vehicle_type
                        ");

                        while($t = mysqli_fetch_assoc($types))
                        {
                        ?>

                        <option
                        value="<?php echo $t['vehicle_type']; ?>"
                        <?php if($type == $t['vehicle_type']) echo "selected"; ?>>

                        <?php echo $t['vehicle_type']; ?>

                        </option>

                        <?php } ?>

                    </select>

                </div>

                <div class="col-md-4">

                    <label class="form-label">Policy Status</label>

                    <select name="status" class="form-select">

                        <option value="">All Status</option>
                        <option value="Active" <?php if($status=="Active") echo "selected"; ?>>Active</option>
                        <option value="Expiring Soon" <?php if($status=="Expiring Soon") echo "selected"; ?>>Expiring Soon</option>
                        <option value="Expired" <?php if($status=="Expired") echo "selected"; ?>>Expired</option>

                    </select>

                </div>

            </div>

            <br>

            <button class="btn btn-success">
                <i class="fa-solid fa-filter"></i>
                Apply Filter
            </button>

            <a href="reports.php" class="btn btn-secondary">
                Reset
            </a>

        </form>

    </div>

</div>
<div class="card shadow report-output">

<div class="card-header bg-primary text-white">

<h5 class="mb-0">

Vehicle Insurance Report

</h5>

</div>

<div class="card-body">

<div class="table-responsive">

<table class="table table-bordered table-hover align-middle">

<thead>

<tr>

<th>Customer</th>
<th>Vehicle No</th>
<th>Type</th>
<th>Company</th>
<th>Policy No</th>
<th>Premium</th>
<th>Expiry Date</th>
<th>Status</th>

</tr>

</thead>

<tbody>

<?php

while($row = mysqli_fetch_assoc($result))
{

    if($row['policy_expiry'] < $today)
        $policyStatus = "Expired";
    elseif($row['policy_expiry'] <= $warning)
        $policyStatus = "Expiring Soon";
    else
        $policyStatus = "Active";

    // Apply status filter after calculating the status
    if($status != "" && $status != $policyStatus)
    {
        continue;
    }

    if($policyStatus=="Expired")
        $badge="<span class='badge bg-danger'>Expired</span>";
    elseif($policyStatus=="Expiring Soon")
        $badge="<span class='badge bg-warning text-dark'>Expiring Soon</span>";
    else
        $badge="<span class='badge bg-success'>Active</span>";

?>

<tr>

<td><?php echo htmlspecialchars($row['customer_name']); ?></td>

<td><?php echo htmlspecialchars($row['vehicle_number']); ?></td>

<td><?php echo htmlspecialchars($row['vehicle_type']); ?></td>

<td><?php echo htmlspecialchars($row['insurance_company']); ?></td>

<td><?php echo htmlspecialchars($row['policy_number']); ?></td>

<td>₹ <?php echo number_format($row['premium_amount'],2); ?></td>

<td><?php echo date("d-m-Y",strtotime($row['policy_expiry'])); ?></td>

<td><?php echo $badge; ?></td>

</tr>

<?php

}

?>

</tbody>

</table>

</div>

</div>

</div>

</div>

</div>

<?php include("../includes/footer.php"); ?>
