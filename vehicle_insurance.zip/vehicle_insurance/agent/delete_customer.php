<?php
session_start();
include("../config/db.php");

if (!isset($_SESSION['agent_id'])) {
    header("Location: ../login.php");
    exit();
}

if (!isset($_GET['id'])) {
    header("Location: customers.php");
    exit();
}

$agentId = (int) $_SESSION['agent_id'];
$id = (int)$_GET['id'];

/* Check whether the customer exists */
$check = mysqli_query($conn, "SELECT * FROM customers WHERE customer_id='$id' AND agent_id='$agentId'");

if (mysqli_num_rows($check) == 0) {
    echo "<script>
            alert('Customer not found.');
            window.location='customers.php';
          </script>";
    exit();
}

/*
|--------------------------------------------------------------------------
| Check whether this customer has vehicles
|--------------------------------------------------------------------------
*/

$vehicleCheck = mysqli_query($conn, "
SELECT COUNT(*) AS total
FROM vehicles
WHERE customer_id='$id' AND agent_id='$agentId'
");

$data = mysqli_fetch_assoc($vehicleCheck);

if($data['total'] > 0)
{
    echo "<script>
    alert('Cannot delete this customer because vehicles are assigned to this customer.');
    window.location='customers.php';
    </script>";
    exit();
}

/*
|--------------------------------------------------------------------------
| Delete Customer
|--------------------------------------------------------------------------
*/

$delete = mysqli_query($conn, "
DELETE FROM customers
WHERE customer_id='$id' AND agent_id='$agentId'
");

if($delete)
{
    echo "<script>
    alert('Customer deleted successfully.');
    window.location='customers.php';
    </script>";
}
else
{
    echo "<script>
    alert('Unable to delete customer.');
    window.location='customers.php';
    </script>";
}
?>