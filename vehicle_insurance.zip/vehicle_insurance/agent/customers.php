 
 <?php
session_start();
include("../config/db.php");

if (!isset($_SESSION['agent_id'])) {
    header("Location: ../login.php");
    exit();
}

$agentId = (int) $_SESSION['agent_id'];
$search = "";

$sql = "SELECT * FROM customers WHERE agent_id='$agentId'";

if(isset($_GET['search']) && $_GET['search']!="")
{
    $search = mysqli_real_escape_string($conn,$_GET['search']);

    $sql .= " AND (
        customer_name LIKE '%$search%'
        OR phone LIKE '%$search%'
        OR email LIKE '%$search%')";
}

$sql .= " ORDER BY customer_name ASC";

$result = mysqli_query($conn,$sql);
?>

<?php include("../includes/header.php"); ?>
<?php include("../includes/sidebar.php"); ?>

<div class="content">

<div class="container-fluid">

<div class="d-flex justify-content-between align-items-center mb-4">

<h2>
<i class="fa-solid fa-users"></i>
Customer Management
</h2>

<a href="add_customer.php" class="btn btn-success">
<i class="fa-solid fa-user-plus"></i>
Add Customer
</a>

</div>
<div class="card shadow mb-4">

<div class="card-body">

<form method="GET">

<div class="row">

<div class="col-md-5">

<input
type="text"
name="search"
class="form-control"
placeholder="Search Customer..."
value="<?php echo htmlspecialchars($search); ?>">

</div>

<div class="col-md-2">

<button class="btn btn-primary w-100">
<i class="fa-solid fa-search"></i>
Search
</button>

</div>

<div class="col-md-2">

<a href="customers.php" class="btn btn-secondary w-100">
Reset
</a>

</div>

</div>

</form>

</div>

</div>

<div class="card shadow">

    <div class="card-header bg-success text-white">

        <h5 class="mb-0">
            Customer List
        </h5>

    </div>

    <div class="card-body">

        <div class="table-responsive">

            <table class="table table-bordered table-hover align-middle">

                <thead>

                    <tr>

                        <th>ID</th>
                        <th>Customer Name</th>
                        <th>Phone</th>
                        <th>Email</th>
                        <th>Address</th>
                        <th width="160">Action</th>

                    </tr>

                </thead>

                <tbody>

                <?php

                if(mysqli_num_rows($result)>0)
                {

                    while($row=mysqli_fetch_assoc($result))
                    {

                ?>

                    <tr>

                        <td><?php echo $row['customer_id']; ?></td>

                        <td><?php echo htmlspecialchars($row['customer_name']); ?></td>

                        <td><?php echo htmlspecialchars($row['phone']); ?></td>

                        <td><?php echo htmlspecialchars($row['email']); ?></td>

                        <td><?php echo htmlspecialchars($row['address']); ?></td>

                        <td>

                            <a href="edit_customer.php?id=<?php echo $row['customer_id']; ?>"
                               class="btn btn-primary btn-sm">

                                <i class="fa-solid fa-pen-to-square"></i>

                            </a>
<a href="delete_customer.php?id=<?php echo $row['customer_id']; ?>"
   class="btn btn-danger btn-sm"
   onclick="return confirm('Are you sure you want to delete this customer?');">

    <i class="fa-solid fa-trash"></i>

</a>
                               
                             

                            </a>

                        </td>

                    </tr>

                <?php

                    }

                }
                else
                {

                ?>

                    <tr>

                        <td colspan="6" class="text-center text-danger">

                            No Customer Records Found

                        </td>

                    </tr>

                <?php

                }

                ?>

                </tbody>

            </table>

        </div>

    </div>

</div>

</div>

</div>

<?php include("../includes/footer.php"); ?>