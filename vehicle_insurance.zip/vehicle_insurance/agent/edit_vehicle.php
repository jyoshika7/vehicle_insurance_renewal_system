<?php
session_start();
include("../config/db.php");

if (!isset($_SESSION['agent_id'])) {
    header("Location: ../login.php");
    exit();
}

if (!isset($_GET['id'])) {
    header("Location: vehicles.php");
    exit();
}

$agentId = (int) $_SESSION['agent_id'];
$id = (int)$_GET['id'];

// Fetch customers for dropdown
$customers = mysqli_query($conn, "SELECT * FROM customers WHERE agent_id='$agentId' ORDER BY customer_name");

// Fetch vehicle details
$result = mysqli_query($conn, "
SELECT *
FROM vehicles
WHERE vehicle_id='$id' AND agent_id='$agentId'
");

if (mysqli_num_rows($result) == 0) {
    echo "<script>
            alert('Vehicle not found');
            window.location='vehicles.php';
          </script>";
    exit();
}

$vehicle = mysqli_fetch_assoc($result);

if(isset($_POST['update']))
{
    $customer_id = $_POST['customer_id'];
    $vehicle_type = $_POST['vehicle_type'];
    $vehicle_model = $_POST['vehicle_model'];
    $vehicle_number = strtoupper(trim($_POST['vehicle_number']));
    $insurance_company = trim($_POST['insurance_company']);
    $policy_number = trim($_POST['policy_number']);
    $premium_amount = $_POST['premium_amount'];
    $policy_expiry = $_POST['policy_expiry'];

    $update = mysqli_query($conn,"
    UPDATE vehicles SET

    customer_id='$customer_id',
    vehicle_type='$vehicle_type',
    vehicle_model='$vehicle_model',
    vehicle_number='$vehicle_number',
    insurance_company='$insurance_company',
    policy_number='$policy_number',
    premium_amount='$premium_amount',
    policy_expiry='$policy_expiry'

    WHERE vehicle_id='$id' AND agent_id='$agentId'
    ");

    if($update)
    {
        echo "<script>
        alert('Vehicle Updated Successfully');
        window.location='vehicles.php';
        </script>";
        exit();
    }
    else
    {
        echo "<script>alert('Update Failed');</script>";
    }
}
?>

<?php include("../includes/header.php"); ?>
<?php include("../includes/sidebar.php"); ?>

<div class="content">

<div class="container-fluid">

<div class="card shadow">

<div class="card-header bg-primary text-white">

<h3>
<i class="fa-solid fa-pen-to-square"></i>
Edit Vehicle
</h3>

</div>

<div class="card-body">

<form method="POST">

<div class="row">
<!-- Customer -->
<div class="col-md-6 mb-3">

    <label class="form-label">Customer</label>

    <select name="customer_id" class="form-select" required>

        <option value="">Select Customer</option>

        <?php
        mysqli_data_seek($customers, 0);

        while($row = mysqli_fetch_assoc($customers))
        {
        ?>

        <option value="<?php echo $row['customer_id']; ?>"
        <?php if($row['customer_id'] == $vehicle['customer_id']) echo "selected"; ?>>

            <?php echo htmlspecialchars($row['customer_name']); ?>

        </option>

        <?php } ?>

    </select>

</div>

<!-- Vehicle Type -->
<div class="col-md-6 mb-3">

    <label class="form-label">Vehicle Type</label>

    <select name="vehicle_type" class="form-select" required>

        <option value="Bike" <?php if($vehicle['vehicle_type']=="Bike") echo "selected"; ?>>Bike</option>

        <option value="Car" <?php if($vehicle['vehicle_type']=="Car") echo "selected"; ?>>Car</option>

        <option value="Auto" <?php if($vehicle['vehicle_type']=="Auto") echo "selected"; ?>>Auto</option>

        <option value="Bus" <?php if($vehicle['vehicle_type']=="Bus") echo "selected"; ?>>Bus</option>

        <option value="Truck" <?php if($vehicle['vehicle_type']=="Truck") echo "selected"; ?>>Truck</option>

        <option value="Van" <?php if($vehicle['vehicle_type']=="Van") echo "selected"; ?>>Van</option>

        <option value="Other" <?php if($vehicle['vehicle_type']=="Other") echo "selected"; ?>>Other</option>

    </select>

</div>

<!-- Vehicle Model -->
<div class="col-md-6 mb-3">

    <label class="form-label">Vehicle Model</label>

    <input
    type="text"
    name="vehicle_model"
    class="form-control"
    value="<?php echo htmlspecialchars($vehicle['vehicle_model']); ?>"
    required>

</div>

<!-- Vehicle Number -->
<div class="col-md-6 mb-3">

    <label class="form-label">Vehicle Number</label>

    <input
    type="text"
    name="vehicle_number"
    class="form-control"
    value="<?php echo htmlspecialchars($vehicle['vehicle_number']); ?>"
    style="text-transform:uppercase;"
    required>

</div>

<!-- Insurance Company -->
<div class="col-md-6 mb-3">

    <label class="form-label">Insurance Company</label>

    <input
    type="text"
    name="insurance_company"
    class="form-control"
    value="<?php echo htmlspecialchars($vehicle['insurance_company']); ?>"
    required>

</div>

<!-- Policy Number -->
<div class="col-md-6 mb-3">

    <label class="form-label">Policy Number</label>

    <input
    type="text"
    name="policy_number"
    class="form-control"
    value="<?php echo htmlspecialchars($vehicle['policy_number']); ?>"
    required>

</div>

<!-- Premium Amount -->
<div class="col-md-6 mb-3">

    <label class="form-label">Premium Amount</label>

    <input
    type="number"
    step="0.01"
    name="premium_amount"
    class="form-control"
    value="<?php echo $vehicle['premium_amount']; ?>"
    required>

</div>

<!-- Policy Expiry -->
<div class="col-md-6 mb-3">

    <label class="form-label">Policy Expiry Date</label>

    <input
    type="date"
    name="policy_expiry"
    class="form-control"
    value="<?php echo $vehicle['policy_expiry']; ?>"
    required>

</div>
</div>

<hr>

<div class="d-flex gap-2">

    <button
        type="submit"
        name="update"
        class="btn btn-primary">

        <i class="fa-solid fa-floppy-disk"></i>
        Update Vehicle

    </button>

    <a
        href="vehicles.php"
        class="btn btn-secondary">

        <i class="fa-solid fa-arrow-left"></i>
        Back

    </a>

    <button
        type="reset"
        class="btn btn-warning">

        <i class="fa-solid fa-rotate"></i>
        Reset

    </button>

</div>

</form>

</div>
</div>

</div>

</div>

<?php include("../includes/footer.php"); ?>