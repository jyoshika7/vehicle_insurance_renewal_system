<?php
session_start();
include("../config/db.php");

if (!isset($_SESSION['agent_id'])) {
    header("Location: ../login.php");
    exit();
}

$agentId = (int) $_SESSION['agent_id'];
$search = "";
$filter_status = "";

$sql = "SELECT * FROM notifications WHERE agent_id='$agentId'";

if(isset($_GET['search']) && $_GET['search']!="")
{
    $search=mysqli_real_escape_string($conn,$_GET['search']);
    $sql.=" AND (
        customer_name LIKE '%$search%'
        OR email LIKE '%$search%'
        OR subject LIKE '%$search%'
    )";
}

if(isset($_GET['status']) && $_GET['status']!="")
{
    $filter_status=mysqli_real_escape_string($conn,$_GET['status']);
    $sql.=" AND status='$filter_status'";
}

$sql.=" ORDER BY sent_date DESC";

$result=mysqli_query($conn,$sql);
$notifications = array();

if(mysqli_num_rows($result)>0)
{
    while($row=mysqli_fetch_assoc($result))
    {
        $notifications[] = $row;
    }
}
?>

<?php include("../includes/header.php"); ?>
<?php include("../includes/sidebar.php"); ?>

<div class="content">

<div class="container-fluid">

<div class="d-flex justify-content-between align-items-center mb-4">
<h2>
<i class="fa-solid fa-bell"></i>
Renewal Notifications
</h2>
</div>

<div class="card shadow mb-4">

<div class="card-body">

<form method="GET">

<div class="row">

<div class="col-md-4">
<input
type="text"
name="search"
class="form-control"
placeholder="Search by Name / Email / Subject"
value="<?php echo htmlspecialchars($search); ?>">
</div>

<div class="col-md-3">
<select name="status" class="form-control">
<option value="">All Status</option>
<option value="Sent" <?php if($filter_status=="Sent") echo "selected"; ?>>Sent</option>
<option value="Failed" <?php if($filter_status=="Failed") echo "selected"; ?>>Failed</option>
</select>
</div>

<div class="col-md-2">
<button class="btn btn-primary w-100">
<i class="fa fa-search"></i> Search
</button>
</div>

<div class="col-md-2">
<a href="notification.php" class="btn btn-secondary w-100">
Reset
</a>
</div>

</div>

</form>

</div>

</div>

<div class="card shadow">

<div class="card-header bg-info text-white">

<h5 class="mb-0">
Notification History
</h5>

</div>

<div class="card-body">

<div class="table-responsive">

<table class="table table-bordered table-hover align-middle">

<thead>

<tr>

<th>ID</th>
<th>Customer Name</th>
<th>Email</th>
<th>Subject</th>
<th>Status</th>
<th>Sent Date</th>
<th>Action</th>

</tr>

</thead>

<tbody>

<?php

if(count($notifications) > 0)
{
$count = 0;

foreach($notifications as $row)
{
$count++;

if($row['status']=="Sent")
{
$status_badge="<span class='badge bg-success'>Sent</span>";
}
elseif($row['status']=="Failed")
{
$status_badge="<span class='badge bg-danger'>Failed</span>";
}
else
{
$status_badge="<span class='badge bg-warning text-dark'>".$row['status']."</span>";
}

$modal_id = "viewModal_" . $count;

?>

<tr>

<td><?php echo $count; ?></td>

<td><?php echo htmlspecialchars($row['customer_name']); ?></td>

<td><?php echo htmlspecialchars($row['email']); ?></td>

<td><?php echo htmlspecialchars($row['subject']); ?></td>

<td><?php echo $status_badge; ?></td>

<td><?php echo date("d-m-Y H:i",strtotime($row['sent_date'])); ?></td>

<td>

<button class="btn btn-info btn-sm" data-bs-toggle="modal" data-bs-target="#<?php echo $modal_id; ?>">
<i class="fa-solid fa-eye"></i> View
</button>

<a href="delete_notification.php?id=<?php echo $row['notification_id']; ?>" class="btn btn-danger btn-sm" onclick="return confirm('Are you sure you want to delete this notification?');">
<i class="fa-solid fa-trash"></i> 
</a>

</td>

</tr>

<?php

}

}
else
{

?>

<tr>

<td colspan="7" class="text-center text-danger">

No Notifications Found

</td>

</tr>

<?php

}

?>

</tbody>

</table>

</div>

</div>

</div>

</div>

</div>

<!-- Modals rendered after table -->
<?php

if(count($notifications) > 0)
{
$count = 0;

foreach($notifications as $row)
{
$count++;
$modal_id = "viewModal_" . $count;

if($row['status']=="Sent")
{
$status_badge="<span class='badge bg-success'>Sent</span>";
}
elseif($row['status']=="Failed")
{
$status_badge="<span class='badge bg-danger'>Failed</span>";
}
else
{
$status_badge="<span class='badge bg-warning text-dark'>".$row['status']."</span>";
}

?>

<!-- Modal for viewing notification details -->
<div class="modal fade" id="<?php echo $modal_id; ?>" tabindex="-1" aria-hidden="true">
<div class="modal-dialog modal-lg">
<div class="modal-content">
<div class="modal-header">
<h5 class="modal-title">Notification Details</h5>
<button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
</div>
<div class="modal-body">
<div class="mb-3">
<label class="fw-bold">Customer Name:</label>
<p><?php echo htmlspecialchars($row['customer_name']); ?></p>
</div>
<div class="mb-3">
<label class="fw-bold">Email:</label>
<p><?php echo htmlspecialchars($row['email']); ?></p>
</div>
<div class="mb-3">
<label class="fw-bold">Subject:</label>
<p><?php echo htmlspecialchars($row['subject']); ?></p>
</div>
<div class="mb-3">
<label class="fw-bold">Message:</label>
<p><?php echo nl2br(htmlspecialchars($row['message'])); ?></p>
</div>
<div class="mb-3">
<label class="fw-bold">Status:</label>
<p><?php echo $status_badge; ?></p>
</div>
<div class="mb-3">
<label class="fw-bold">Sent Date:</label>
<p><?php echo date("d-m-Y H:i:s",strtotime($row['sent_date'])); ?></p>
</div>
</div>
<div class="modal-footer">
<button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Close</button>
</div>
</div>
</div>
</div>

<?php

}

}

?>

<?php include("../includes/footer.php"); ?>
