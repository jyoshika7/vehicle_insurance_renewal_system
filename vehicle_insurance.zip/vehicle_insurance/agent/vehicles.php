<?php
session_start();
include("../config/db.php");

if (!isset($_SESSION['agent_id'])) {
    header("Location: ../login.php");
    exit();
}

$agentId = (int) $_SESSION['agent_id'];
$today = date("Y-m-d");
$warning = date("Y-m-d", strtotime("+30 days"));

$search = "";

$sql = "
SELECT
v.*,
c.customer_name
FROM vehicles v
JOIN customers c
ON v.customer_id=c.customer_id
WHERE v.agent_id='$agentId' AND c.agent_id='$agentId'
";

if(isset($_GET['search']) && $_GET['search']!="")
{
    $search=mysqli_real_escape_string($conn,$_GET['search']);

    $sql.=" AND (
    c.customer_name LIKE '%$search%'
    OR v.vehicle_number LIKE '%$search%'
    OR v.policy_number LIKE '%$search%'
    )";
}

$sql.=" ORDER BY v.policy_expiry ASC";

$result=mysqli_query($conn,$sql);
?>

<?php include("../includes/header.php"); ?>
<?php include("../includes/sidebar.php"); ?>

<div class="content">

<div class="container-fluid">

<div class="d-flex justify-content-between align-items-center mb-4">

<h2>
<i class="fa-solid fa-car"></i>
Vehicle Management
</h2>

<div class="text-end mb-3">
    <a href="add_vehicle.php" class="btn btn-success">
        <i class="fa-solid fa-plus"></i> Add Vehicle
    </a>
</div>

</div>

<div class="card shadow mb-4">

<div class="card-body">

<form method="GET">

<div class="row">

<div class="col-md-5">

<input
type="text"
name="search"
class="form-control"
placeholder="Search Customer / Vehicle / Policy"
value="<?php echo htmlspecialchars($search); ?>">

</div>

<div class="col-md-2">

<button class="btn btn-primary w-100">
<i class="fa fa-search"></i>
Search
</button>

</div>

<div class="col-md-2">

<a href="vehicles.php" class="btn btn-secondary w-100">
Reset
</a>

</div>

</div>

</form>

</div>

</div>

<div class="card shadow">

<div class="card-header bg-success text-white">

<h5 class="mb-0">
Vehicle List
</h5>

</div>

<div class="card-body">

<div class="table-responsive">

<table class="table table-bordered table-hover align-middle">

<thead>

<tr>

<th>ID</th>
<th>Customer</th>
<th>Vehicle No</th>
<th>Type</th>
<th>Model</th>
<th>Company</th>
<th>Policy No</th>
<th>Premium</th>
<th>Expiry</th>
<th>Status</th>
<th width="160">Action</th>

</tr>

</thead>

<tbody>

<?php

if(mysqli_num_rows($result)>0)
{

while($row=mysqli_fetch_assoc($result))
{

if($row['policy_expiry']<$today)
{
$status="<span class='badge bg-danger'>Expired</span>";
}
elseif($row['policy_expiry']<=$warning)
{
$status="<span class='badge bg-warning text-dark'>Expiring Soon</span>";
}
else
{
$status="<span class='badge bg-success'>Active</span>";
}

?>

<tr>

<td><?php echo $row['vehicle_id']; ?></td>

<td><?php echo htmlspecialchars($row['customer_name']); ?></td>

<td><?php echo htmlspecialchars($row['vehicle_number']); ?></td>

<td><?php echo htmlspecialchars($row['vehicle_type']); ?></td>

<td><?php echo htmlspecialchars($row['vehicle_model']); ?></td>

<td><?php echo htmlspecialchars($row['insurance_company']); ?></td>

<td><?php echo htmlspecialchars($row['policy_number']); ?></td>

<td>₹ <?php echo number_format($row['premium_amount'],2); ?></td>

<td><?php echo date("d-m-Y",strtotime($row['policy_expiry'])); ?></td>

<td><?php echo $status; ?></td>

<td>

<a
href="edit_vehicle.php?id=<?php echo $row['vehicle_id']; ?>"
class="btn btn-primary btn-sm">

<i class="fa fa-edit"></i>

</a>

 <a href="delete_vehicle.php?id=<?php echo $row['vehicle_id']; ?>"
       class="btn btn-danger btn-sm"
       onclick="return confirm('Are you sure you want to delete this vehicle?');">
        <i class="fa-solid fa-trash"></i>
    </a>


</td>

</tr>

<?php

}

}
else
{

?>

<tr>

<td colspan="11" class="text-center text-danger">

No Vehicle Records Found

</td>

</tr>

<?php

}

?>

</tbody>

</table>

</div>

</div>

</div>

</div>

</div>

<?php include("../includes/footer.php"); ?>