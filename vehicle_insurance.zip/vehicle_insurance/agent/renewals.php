<?php
session_start();
include("../config/db.php");

if (!isset($_SESSION['agent_id'])) {
    header("Location: ../login.php");
    exit();
}

$today = date("Y-m-d");
$warning = date("Y-m-d", strtotime("+30 days"));

$agentId = (int) $_SESSION['agent_id'];
$search = "";

$sql = "
SELECT
v.*,
c.customer_name
FROM vehicles v
INNER JOIN customers c
ON v.customer_id = c.customer_id
WHERE v.agent_id='$agentId' AND c.agent_id='$agentId'
";

if(isset($_GET['search']) && $_GET['search']!="")
{
    $search = mysqli_real_escape_string($conn,$_GET['search']);

    $sql .= " AND (
        c.customer_name LIKE '%$search%'
        OR v.vehicle_number LIKE '%$search%'
        OR v.policy_number LIKE '%$search%')";
}

$sql .= " ORDER BY v.policy_expiry ASC";

$result = mysqli_query($conn,$sql);
?>

<?php include("../includes/header.php"); ?>
<?php include("../includes/sidebar.php"); ?>

<div class="content">

<div class="container-fluid">

<div class="d-flex justify-content-between align-items-center mb-4 renewal-header">

<h2>
<i class="fa-solid fa-rotate"></i>
Renewal Management
</h2>

<button onclick="window.print()" class="btn btn-primary renewal-print-button">
<i class="fa-solid fa-print"></i>
Print Report
</button>

</div>

<div class="card shadow mb-4 renewal-search">

<div class="card-body">

<form method="GET">

<div class="row">

<div class="col-md-5">

<input
type="text"
name="search"
class="form-control"
placeholder="Search Customer / Vehicle / Policy"
value="<?php echo htmlspecialchars($search); ?>">

</div>

<div class="col-md-2">

<button class="btn btn-primary w-100">
<i class="fa-solid fa-search"></i>
Search
</button>

</div>

<div class="col-md-2">

<a href="renewals.php" class="btn btn-secondary w-100">
Reset
</a>

</div>

</div>

</form>

</div>

</div>

<div class="card shadow renewal-output">

    <div class="card-header bg-success text-white">

        <h5 class="mb-0">
            Policy Renewal List
        </h5>

    </div>

    <div class="card-body">

        <div class="table-responsive">

            <table class="table table-bordered table-hover align-middle">

                <thead>

                <tr>

                    <th>Customer</th>
                    <th>Vehicle No</th>
                    <th>Vehicle Type</th>
                    <th>Insurance Company</th>
                    <th>Policy Number</th>
                    <th>Premium</th>
                    <th>Expiry Date</th>
                    <th>Status</th>
                    <th>Renewed</th>
                    <th width="130">Action</th>

                </tr>

                </thead>

                <tbody>

                <?php

                if(mysqli_num_rows($result) > 0)
                {
                    while($row = mysqli_fetch_assoc($result))
                    {

                        if($row['policy_expiry'] < $today)
                        {
                            $status = "<span class='badge bg-danger'>Expired</span>";
                        }
                        elseif($row['policy_expiry'] <= $warning)
                        {
                            $status = "<span class='badge bg-warning text-dark'>Expiring Soon</span>";
                        }
                        else
                        {
                            $status = "<span class='badge bg-success'>Active</span>";
                        }

                ?>

                <tr>

                    <td><?php echo htmlspecialchars($row['customer_name']); ?></td>

                    <td><?php echo htmlspecialchars($row['vehicle_number']); ?></td>

                    <td><?php echo htmlspecialchars($row['vehicle_type']); ?></td>

                    <td><?php echo htmlspecialchars($row['insurance_company']); ?></td>

                    <td><?php echo htmlspecialchars($row['policy_number']); ?></td>

                    <td>₹ <?php echo number_format($row['premium_amount'],2); ?></td>

                    <td><?php echo date("d-m-Y",strtotime($row['policy_expiry'])); ?></td>

                    <td><?php echo $status; ?></td>

                    <td>

                        <?php
                        if($row['renewed']=="Yes")
                        {
                            echo "<span class='badge bg-success'>Yes</span>";
                        }
                        else
                        {
                            echo "<span class='badge bg-secondary'>No</span>";
                        }
                        ?>

                    </td>

                    <td>

                        <a href="renew_policy.php?id=<?php echo $row['vehicle_id']; ?>"
                           class="btn btn-warning btn-sm">

                            <i class="fa-solid fa-rotate"></i>
                            Renew

                        </a>

                    </td>

                </tr>

                <?php
                    }
                }
                else
                {
                ?>

                <tr>

                    <td colspan="10" class="text-center text-danger">

                        No Records Found

                    </td>

                </tr>

                <?php } ?>

                </tbody>

            </table>

        </div>

    </div>

</div>

</div>

</div>

<?php include("../includes/footer.php"); ?>
