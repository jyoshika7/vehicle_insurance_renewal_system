<?php
session_start();
include("../config/db.php");

if (!isset($_SESSION['agent_id'])) {
    header("Location: ../login.php");
    exit();
}

$agentId = (int) $_SESSION['agent_id'];

if(isset($_POST['save']))
{
    $customer_id = $_POST['customer_id'];
    $vehicle_type = $_POST['vehicle_type'];
    $vehicle_model = $_POST['vehicle_model'];
    $vehicle_number = strtoupper($_POST['vehicle_number']);
    $insurance_company = $_POST['insurance_company'];
    $policy_number = $_POST['policy_number'];
    $premium_amount = $_POST['premium_amount'];
    $policy_expiry = $_POST['policy_expiry'];

    $renewal_date = NULL;
    $status = "Active";
    $renewed = "No";

    $sql = "INSERT INTO vehicles
    (
        agent_id,
        customer_id,
        vehicle_type,
        vehicle_model,
        vehicle_number,
        insurance_company,
        policy_number,
        premium_amount,
        policy_expiry,
        renewal_date,
        status,
        renewed
    )
    VALUES
    (
        '$agentId',
        '$customer_id',
        '$vehicle_type',
        '$vehicle_model',
        '$vehicle_number',
        '$insurance_company',
        '$policy_number',
        '$premium_amount',
        '$policy_expiry',
        NULL,
        '$status',
        '$renewed'
    )";

    if(mysqli_query($conn,$sql))
    {
        echo "<script>
        alert('Vehicle Added Successfully');
        window.location='vehicles.php';
        </script>";
        exit();
    }
    else
    {
        echo "<script>alert('Error adding vehicle');</script>";
    }
}
?>

<?php include("../includes/header.php"); ?>
<?php include("../includes/sidebar.php"); ?>

<div class="content">
<div class="container-fluid">

<div class="card shadow">

<div class="card-header bg-success text-white">
<h3>
<i class="fa-solid fa-car"></i>
Add Vehicle
</h3>
</div>

<div class="card-body">

<form method="POST">

<div class="row">
<div class="col-md-6 mb-3">

<label class="form-label">
Customer
</label>

<select name="customer_id" class="form-select" required>

<option value="">
Select Customer
</option>

<?php

$result=mysqli_query($conn,"SELECT * FROM customers WHERE agent_id='$agentId' ORDER BY customer_name");

while($row=mysqli_fetch_assoc($result))
{
?>

<option value="<?php echo $row['customer_id']; ?>">

<?php echo $row['customer_name']; ?>

</option>

<?php
}
?>

</select>

</div>
<!-- Vehicle Type -->
<div class="col-md-6 mb-3">
    <label class="form-label">Vehicle Type</label>

    <select name="vehicle_type" class="form-select" required>
        <option value="">Select Vehicle Type</option>
        <option>Bike</option>
        <option>Car</option>
        <option>Auto</option>
        <option>Bus</option>
        <option>Truck</option>
        <option>Van</option>
        <option>Other</option>
    </select>
</div>

<!-- Vehicle Model -->
<div class="col-md-6 mb-3">
    <label class="form-label">Vehicle Model</label>

    <input
        type="text"
        name="vehicle_model"
        class="form-control"
        placeholder="Example: Hyundai i20"
        required>
</div>

<!-- Vehicle Number -->
<div class="col-md-6 mb-3">
    <label class="form-label">Vehicle Number</label>

    <input
        type="text"
        name="vehicle_number"
        class="form-control"
        placeholder="TN34JS3004"
        style="text-transform:uppercase;"
        required>
</div>

<!-- Insurance Company -->
<div class="col-md-6 mb-3">
    <label class="form-label">Insurance Company</label>

    <input
        type="text"
        name="insurance_company"
        class="form-control"
        placeholder="Insurance Company"
        required>
</div>

<!-- Policy Number -->
<div class="col-md-6 mb-3">
    <label class="form-label">Policy Number</label>

    <input
        type="text"
        name="policy_number"
        class="form-control"
        placeholder="Policy Number"
        required>
</div>

<!-- Premium Amount -->
<div class="col-md-6 mb-3">
    <label class="form-label">Premium Amount</label>

    <input
        type="number"
        step="0.01"
        name="premium_amount"
        class="form-control"
        placeholder="Premium Amount"
        required>
</div>

<!-- Policy Expiry -->
<div class="col-md-6 mb-3">
    <label class="form-label">Policy Expiry Date</label>

    <input
        type="date"
        name="policy_expiry"
        class="form-control"
        required>
</div>
</div>

<hr>

<div class="d-flex gap-2">

    <button type="submit"
            name="save"
            class="btn btn-success">
        <i class="fa-solid fa-floppy-disk"></i>
        Save Vehicle
    </button>

    <a href="vehicles.php" class="btn btn-secondary">
        <i class="fa-solid fa-arrow-left"></i>
        Back
    </a>

    <button type="reset" class="btn btn-warning">
        <i class="fa-solid fa-rotate"></i>
        Reset
    </button>

</div>

</form>

</div>
</div>

</div>
</div>

<?php include("../includes/footer.php"); ?>