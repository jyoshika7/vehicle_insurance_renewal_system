<?php
session_start();

if (!isset($_GET['agent_id'])) {
    header("Location: ../login.php");
    exit();
}

$agentId = (int) $_GET['agent_id'];

if (!isset($_SESSION['logged_agents']) || !is_array($_SESSION['logged_agents']) || !isset($_SESSION['logged_agents'][$agentId])) {
    header("Location: ../login.php");
    exit();
}

$_SESSION['agent_id'] = $agentId;
$_SESSION['agent_name'] = $_SESSION['logged_agents'][$agentId]['name'];

header("Location: dashboard.php");
exit();
