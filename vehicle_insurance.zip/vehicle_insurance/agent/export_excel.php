<?php
session_start();
include("../config/db.php");

require("../vendor/autoload.php");

use PhpOffice\PhpSpreadsheet\Spreadsheet;
use PhpOffice\PhpSpreadsheet\Writer\Xlsx;

if (!isset($_SESSION['agent_id'])) {
    header("Location: ../login.php");
    exit();
}

$spreadsheet = new Spreadsheet();
$sheet = $spreadsheet->getActiveSheet();

$sheet->setTitle("Vehicle Insurance Report");

// Header row
$headers = [
    'A1' => 'Customer',
    'B1' => 'Vehicle Number',
    'C1' => 'Vehicle Type',
    'D1' => 'Insurance Company',
    'E1' => 'Policy Number',
    'F1' => 'Premium',
    'G1' => 'Policy Expiry',
    'H1' => 'Status'
];

foreach ($headers as $cell => $value) {
    $sheet->setCellValue($cell, $value);
}

$sheet->getStyle('A1:H1')->getFont()->setBold(true);

$agentId = (int) $_SESSION['agent_id'];
$today = date("Y-m-d");
$warning = date("Y-m-d", strtotime("+30 days"));

$query = "
SELECT
    v.*,
    c.customer_name
FROM vehicles v
JOIN customers c
ON v.customer_id = c.customer_id
WHERE v.agent_id='$agentId' AND c.agent_id='$agentId'
ORDER BY v.policy_expiry ASC
";

$result = mysqli_query($conn, $query);

$row = 2;

while ($data = mysqli_fetch_assoc($result)) {

    if ($data['policy_expiry'] < $today) {
        $status = "Expired";
    } elseif ($data['policy_expiry'] <= $warning) {
        $status = "Expiring Soon";
    } else {
        $status = "Active";
    }

    $sheet->setCellValue('A'.$row, $data['customer_name']);
    $sheet->setCellValue('B'.$row, $data['vehicle_number']);
    $sheet->setCellValue('C'.$row, $data['vehicle_type']);
    $sheet->setCellValue('D'.$row, $data['insurance_company']);
    $sheet->setCellValue('E'.$row, $data['policy_number']);
    $sheet->setCellValue('F'.$row, $data['premium_amount']);
    $sheet->setCellValue('G'.$row, $data['policy_expiry']);
    $sheet->setCellValue('H'.$row, $status);

    $row++;
}

// Auto-size columns
foreach (range('A', 'H') as $col) {
    $sheet->getColumnDimension($col)->setAutoSize(true);
}

$writer = new Xlsx($spreadsheet);

header('Content-Type: application/vnd.openxmlformats-officedocument.spreadsheetml.sheet');
header('Content-Disposition: attachment;filename="Vehicle_Insurance_Report.xlsx"');
header('Cache-Control: max-age=0');

$writer->save('php://output');
exit();