<?php
session_start();
include("../config/db.php");

if (!isset($_SESSION['agent_id'])) {
    header("Location: ../login.php");
    exit();
}

$agentId = (int) $_SESSION['agent_id'];

if(isset($_POST['save']))
{
    $customer_name = trim($_POST['customer_name']);
    $phone = trim($_POST['phone']);
    $email = trim($_POST['email']);
    $address = trim($_POST['address']);

    $insert = mysqli_query($conn,"
    INSERT INTO customers
    (
        agent_id,
        customer_name,
        phone,
        email,
        address
    )
    VALUES
    (
        '$agentId',
        '$customer_name',
        '$phone',
        '$email',
        '$address'
    )
    ");

    if($insert)
    {
        echo "<script>
        alert('Customer Added Successfully');
        window.location='customers.php';
        </script>";
        exit();
    }
    else
    {
        echo "<script>alert('Unable to add customer');</script>";
    }
}
?>

<?php include("../includes/header.php"); ?>
<?php include("../includes/sidebar.php"); ?>

<div class="content">

<div class="container-fluid">

<div class="card shadow">

<div class="card-header bg-success text-white">

<h3>
<i class="fa-solid fa-user-plus"></i>
Add Customer
</h3>

</div>

<div class="card-body">

<form method="POST">

<div class="row">
<div class="col-md-6 mb-3">

<label class="form-label">
Customer Name
</label>

<input
type="text"
name="customer_name"
class="form-control"
placeholder="Enter Customer Name"
required>

</div>

<div class="col-md-6 mb-3">

<label class="form-label">
Phone Number
</label>

<input
type="text"
name="phone"
class="form-control"
placeholder="Enter Phone Number"
maxlength="10"
required>

</div>

<div class="col-md-6 mb-3">

<label class="form-label">
Email Address
</label>

<input
type="email"
name="email"
class="form-control"
placeholder="Enter Email Address">

</div>

<div class="col-md-12 mb-3">

<label class="form-label">
Address
</label>

<textarea
name="address"
class="form-control"
rows="4"
placeholder="Enter Customer Address"
required></textarea>

</div>
</div>

<hr>

<div class="d-flex gap-2">

<button
type="submit"
name="save"
class="btn btn-success">

<i class="fa-solid fa-floppy-disk"></i>

Save Customer

</button>

<a
href="customers.php"
class="btn btn-secondary">

<i class="fa-solid fa-arrow-left"></i>

Back

</a>

<button
type="reset"
class="btn btn-warning">

<i class="fa-solid fa-rotate"></i>

Reset

</button>

</div>

</form>

</div>

</div>

</div>

</div>

<?php include("../includes/footer.php"); ?>