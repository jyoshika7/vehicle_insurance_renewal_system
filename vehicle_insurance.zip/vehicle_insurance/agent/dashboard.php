<?php
session_start();
include("../config/db.php");

if (!isset($_SESSION['agent_id'])) {
    header("Location: ../login.php");
    exit();
}

$agentId = (int) $_SESSION['agent_id'];
$today = date("Y-m-d");
$warning = date("Y-m-d", strtotime("+30 days"));

/* Dashboard Statistics */

// Customers
$totalCustomers = mysqli_fetch_assoc(
    mysqli_query($conn, "SELECT COUNT(*) AS total FROM customers WHERE agent_id='$agentId'")
)['total'];

// Vehicles
$totalVehicles = mysqli_fetch_assoc(
    mysqli_query($conn, "SELECT COUNT(*) AS total FROM vehicles WHERE agent_id='$agentId'")
)['total'];

// Active
$active = mysqli_fetch_assoc(
    mysqli_query(
        $conn,
        "SELECT COUNT(*) AS total
         FROM vehicles
         WHERE agent_id='$agentId' AND policy_expiry > '$warning'"
    )
)['total'];

// Expiring
$expiring = mysqli_fetch_assoc(
    mysqli_query(
        $conn,
        "SELECT COUNT(*) AS total
         FROM vehicles
         WHERE agent_id='$agentId' AND policy_expiry BETWEEN '$today' AND '$warning'"
    )
)['total'];

// Expired
$expired = mysqli_fetch_assoc(
    mysqli_query(
        $conn,
        "SELECT COUNT(*) AS total
         FROM vehicles
         WHERE agent_id='$agentId' AND policy_expiry < '$today'"
    )
)['total'];

// Premium
$premium = mysqli_fetch_assoc(
    mysqli_query(
        $conn,
        "SELECT SUM(premium_amount) AS total FROM vehicles WHERE agent_id='$agentId'"
    )
)['total'];

if ($premium == NULL) {
    $premium = 0;
}

$todayCount = mysqli_fetch_assoc(mysqli_query($conn,"
SELECT COUNT(*) AS total
FROM vehicles
WHERE agent_id='$agentId' AND policy_expiry = CURDATE()
"))['total'];

$weekCount = mysqli_fetch_assoc(mysqli_query($conn,"
SELECT COUNT(*) AS total
FROM vehicles
WHERE agent_id='$agentId' AND policy_expiry BETWEEN CURDATE() AND DATE_ADD(CURDATE(), INTERVAL 7 DAY)
"))['total'];

$expiredCount = mysqli_fetch_assoc(mysqli_query($conn,"
SELECT COUNT(*) AS total
FROM vehicles
WHERE agent_id='$agentId' AND policy_expiry < CURDATE()
"))['total'];

$chartData = [
    $active,
    $expiring,
    $expired
];

/* Recent Policies */

$recent = mysqli_query($conn,"
SELECT
    c.customer_name,
    v.vehicle_number,
    v.insurance_company,
    v.policy_expiry
FROM vehicles v
INNER JOIN customers c
ON v.customer_id=c.customer_id
WHERE v.agent_id='$agentId' AND c.agent_id='$agentId'
ORDER BY v.policy_expiry ASC
LIMIT 10
");
?>

<?php include("../includes/header.php"); ?>
<?php include("../includes/sidebar.php"); ?>

<div class="content">

<div class="container-fluid">

<div class="d-flex justify-content-between align-items-center mb-4">

<h2>
<i class="fa-solid fa-gauge-high"></i>
Dashboard
</h2>

<h5 class="text-secondary">
<?php echo date("d M Y"); ?>
</h5>

</div>

<h3 class="mb-4">
Welcome,
<strong><?php echo htmlspecialchars($_SESSION['agent_name'] ?? 'Agent'); ?></strong>
</h3>

<!-- Dashboard Statistic Cards -->
<div class="row g-4 mb-4">

    <div class="col-md-4">
        <div class="card text-white bg-primary shadow h-100">
            <div class="card-body">
                <h5>
                    <i class="fa-solid fa-users"></i>
                    Customers
                </h5>

                <h1><?php echo $totalCustomers; ?></h1>
            </div>
        </div>
    </div>

    <div class="col-md-4">
        <div class="card text-white bg-success shadow h-100">
            <div class="card-body">
                <h5>
                    <i class="fa-solid fa-car"></i>
                    Vehicles
                </h5>

                <h1><?php echo $totalVehicles; ?></h1>
            </div>
        </div>
    </div>

    <div class="col-md-4">
        <div class="card text-white bg-info shadow h-100">
            <div class="card-body">
                <h5>
                    <i class="fa-solid fa-indian-rupee-sign"></i>
                    Total Premium
                </h5>

                <h1>₹ <?php echo number_format($premium,2); ?></h1>
            </div>
        </div>
    </div>

</div>
<div class="row mb-4">

    <div class="col-md-4">

        <div class="card border-primary shadow">

            <div class="card-body text-center">

                <h5 class="text-primary">
                    <i class="fa-solid fa-calendar-day"></i><br>
                    Expiring Today
                </h5>

                <h2><?php echo $todayCount; ?></h2>

            </div>

        </div>

    </div>

    <div class="col-md-4">

        <div class="card border-warning shadow">

            <div class="card-body text-center">

                <h5 class="text-warning">
                    <i class="fa-solid fa-clock"></i><br>
                    Next 7 Days
                </h5>

                <h2><?php echo $weekCount; ?></h2>

            </div>

        </div>

    </div>

    <div class="col-md-4">

        <div class="card border-danger shadow">

            <div class="card-body text-center">

                <h5 class="text-danger">
                    <i class="fa-solid fa-triangle-exclamation"></i><br>
                    Expired
                </h5>

                <h2><?php echo $expiredCount; ?></h2>

            </div>

        </div>

    </div>

</div>
<div class="row mt-4">

    <div class="col-lg-6 mb-4">

        <div class="card shadow">

            <div class="card-header bg-primary text-white">
                <h5 class="mb-0">Policy Status</h5>
            </div>

            <div class="card-body text-center">

                <canvas id="statusChart" style="width: 100%; max-width: 360px; height: 360px; margin: 0 auto; display: block;"></canvas>

            </div>

        </div>

    </div>

    <div class="col-lg-6 mb-4">

        <div class="card shadow">

            <div class="card-header bg-success text-white">
                <h5 class="mb-0">Policy Summary</h5>
            </div>

            <div class="card-body text-center">

                <canvas id="summaryChart" style="width: 100%; max-width: 360px; height: 360px; margin: 0 auto; display: block;"></canvas>

            </div>

        </div>

    </div>

</div>
<!-- Policy Status Cards -->
<div class="row g-4 mb-4">

    <div class="col-md-4">
        <div class="card shadow h-100">
            <div class="card-body text-center">

                <h3 class="text-success">
                    Active Policies
                </h3>

                <h1><?php echo $active; ?></h1>

            </div>
        </div>
    </div>

    <div class="col-md-4">
        <div class="card shadow h-100">
            <div class="card-body text-center">

                <h3 class="text-warning">
                    Expiring Soon
                </h3>

                <h1><?php echo $expiring; ?></h1>

            </div>
        </div>
    </div>

    <div class="col-md-4">
        <div class="card shadow h-100">
            <div class="card-body text-center">

                <h3 class="text-danger">
                    Expired Policies
                </h3>

                <h1><?php echo $expired; ?></h1>

            </div>
        </div>
    </div>

</div>

<!-- Quick Action Buttons -->
<div class="card shadow mb-4">

    <div class="card-header bg-success text-white">

        <h5 class="mb-0">
            Quick Actions
        </h5>

    </div>

    <div class="card-body">

        <a href="add_customer.php" class="btn btn-primary me-2 mb-2">
            <i class="fa-solid fa-user-plus"></i>
            Add Customer
        </a>

        <a href="add_vehicle.php" class="btn btn-success me-2 mb-2">
            <i class="fa-solid fa-car"></i>
            Add Vehicle
        </a>

        <a href="renewals.php" class="btn btn-warning me-2 mb-2">
            <i class="fa-solid fa-rotate"></i>
            Renew Policies
        </a>

        <a href="reports.php" class="btn btn-info text-white mb-2">
            <i class="fa-solid fa-chart-column"></i>
            Reports
        </a>

    </div>

</div>

<!-- Recent Policies Table -->
<div class="card shadow">

    <div class="card-header bg-success text-white">

        <h5 class="mb-0">
            Recent Policies
        </h5>

    </div>

    <div class="card-body">

        <div class="table-responsive">

            <table class="table table-bordered table-hover align-middle">

                <thead>

                    <tr>

                        <th>Customer</th>
                        <th>Vehicle No</th>
                        <th>Insurance Company</th>
                        <th>Expiry Date</th>
                        <th>Status</th>

                    </tr>

                </thead>

                <tbody>

                <?php while($row = mysqli_fetch_assoc($recent)) { ?>

                    <?php

                    if($row['policy_expiry'] < $today)
                    {
                        $badge = "<span class='badge bg-danger'>Expired</span>";
                    }
                    elseif($row['policy_expiry'] <= $warning)
                    {
                        $badge = "<span class='badge bg-warning text-dark'>Expiring Soon</span>";
                    }
                    else
                    {
                        $badge = "<span class='badge bg-success'>Active</span>";
                    }

                    ?>

                    <tr>

                        <td><?php echo htmlspecialchars($row['customer_name']); ?></td>

                        <td><?php echo htmlspecialchars($row['vehicle_number']); ?></td>

                        <td><?php echo htmlspecialchars($row['insurance_company']); ?></td>

                        <td><?php echo date("d-m-Y", strtotime($row['policy_expiry'])); ?></td>

                        <td><?php echo $badge; ?></td>

                    </tr>

                <?php } ?>

                </tbody>

            </table>

        </div>

    </div>

</div>

</div> <!-- container-fluid -->

</div> <!-- content -->
<script>
window.addEventListener('DOMContentLoaded', function () {
    const statusChart = document.getElementById('statusChart');

    new Chart(statusChart, {
        type: 'pie',
        data: {
            labels: ['Active', 'Expiring Soon', 'Expired'],
            datasets: [{
                data: [
                    <?php echo $active; ?>,
                    <?php echo $expiring; ?>,
                    <?php echo $expired; ?>
                ],
                backgroundColor: [
                    '#198754',
                    '#ffc107',
                    '#dc3545'
                ]
            }]
        }
    });

    const summaryChart = document.getElementById('summaryChart');

    new Chart(summaryChart, {
        type: 'bar',
        data: {
            labels: ['Active', 'Expiring', 'Expired'],
            datasets: [{
                label: 'Policies',
                data: [
                    <?php echo $active; ?>,
                    <?php echo $expiring; ?>,
                    <?php echo $expired; ?>
                ]
            }]
        },
        options: {
            responsive: true,
            plugins: {
                legend: {
                    display: false
                }
            }
        }
    });
});
</script>
<?php include("../includes/footer.php"); ?>

