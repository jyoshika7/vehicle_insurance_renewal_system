-- Vehicle Insurance Renewal System database
-- Import this file from phpMyAdmin.

CREATE DATABASE IF NOT EXISTS `vehicle_insurance`
	DEFAULT CHARACTER SET utf8mb4
	COLLATE utf8mb4_general_ci;
USE `vehicle_insurance`;

SET SQL_MODE = 'NO_AUTO_VALUE_ON_ZERO';
SET time_zone = '+00:00';
SET FOREIGN_KEY_CHECKS = 0;

DROP TABLE IF EXISTS `notifications`;
DROP TABLE IF EXISTS `renewal_history`;
DROP TABLE IF EXISTS `vehicles`;
DROP TABLE IF EXISTS `customers`;
DROP TABLE IF EXISTS `agents`;

CREATE TABLE `agents` (
	`agent_id` int(11) NOT NULL AUTO_INCREMENT,
	`name` varchar(100) NOT NULL,
	`username` varchar(50) NOT NULL,
	`password` varchar(255) NOT NULL,
	`created_at` timestamp NOT NULL DEFAULT current_timestamp(),
	PRIMARY KEY (`agent_id`),
	UNIQUE KEY `uq_agents_username` (`username`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

CREATE TABLE `customers` (
	`customer_id` int(11) NOT NULL AUTO_INCREMENT,
	`agent_id` int(11) NOT NULL,
	`customer_name` varchar(100) NOT NULL,
	`phone` varchar(20) NOT NULL,
	`email` varchar(100) NOT NULL,
	`address` text NOT NULL,
	`created_at` timestamp NOT NULL DEFAULT current_timestamp(),
	PRIMARY KEY (`customer_id`),
	KEY `idx_customers_agent_id` (`agent_id`),
	KEY `idx_customer_name` (`customer_name`),
	CONSTRAINT `fk_customers_agent` FOREIGN KEY (`agent_id`) REFERENCES `agents` (`agent_id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

CREATE TABLE `vehicles` (
	`vehicle_id` int(11) NOT NULL AUTO_INCREMENT,
	`agent_id` int(11) NOT NULL,
	`customer_id` int(11) NOT NULL,
	`vehicle_type` varchar(50) NOT NULL,
	`vehicle_model` varchar(100) NOT NULL,
	`vehicle_number` varchar(50) NOT NULL,
	`insurance_company` varchar(100) NOT NULL,
	`policy_number` varchar(50) NOT NULL,
	`premium_amount` decimal(10,2) NOT NULL,
	`policy_expiry` date NOT NULL,
	`renewal_date` date DEFAULT NULL,
	`status` varchar(20) NOT NULL DEFAULT 'Active',
	`renewed` varchar(3) NOT NULL DEFAULT 'No',
	`created_at` timestamp NOT NULL DEFAULT current_timestamp(),
	PRIMARY KEY (`vehicle_id`),
	UNIQUE KEY `uq_vehicles_vehicle_number` (`vehicle_number`),
	UNIQUE KEY `uq_vehicles_policy_number` (`policy_number`),
	KEY `idx_vehicles_agent_id` (`agent_id`),
	KEY `idx_vehicles_customer_id` (`customer_id`),
	KEY `idx_insurance_company` (`insurance_company`),
	KEY `idx_policy_expiry` (`policy_expiry`),
	CONSTRAINT `fk_vehicles_agent` FOREIGN KEY (`agent_id`) REFERENCES `agents` (`agent_id`) ON DELETE CASCADE,
	CONSTRAINT `fk_vehicles_customer` FOREIGN KEY (`customer_id`) REFERENCES `customers` (`customer_id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

CREATE TABLE `renewal_history` (
	`history_id` int(11) NOT NULL AUTO_INCREMENT,
	`vehicle_id` int(11) NOT NULL,
	`policy_number` varchar(50) NOT NULL,
	`premium_amount` decimal(10,2) NOT NULL,
	`old_expiry_date` date NOT NULL,
	`new_expiry_date` date NOT NULL,
	`renewal_date` date NOT NULL,
	`agent_id` int(11) NOT NULL,
	`created_at` timestamp NOT NULL DEFAULT current_timestamp(),
	PRIMARY KEY (`history_id`),
	KEY `idx_history_vehicle_id` (`vehicle_id`),
	KEY `idx_history_agent_id` (`agent_id`),
	CONSTRAINT `fk_history_vehicle` FOREIGN KEY (`vehicle_id`) REFERENCES `vehicles` (`vehicle_id`) ON DELETE CASCADE,
	CONSTRAINT `fk_history_agent` FOREIGN KEY (`agent_id`) REFERENCES `agents` (`agent_id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

CREATE TABLE `notifications` (
	`notification_id` int(11) NOT NULL AUTO_INCREMENT,
	`agent_id` int(11) NOT NULL,
	`vehicle_id` int(11) NOT NULL,
	`customer_name` varchar(100) NOT NULL,
	`email` varchar(100) NOT NULL,
	`subject` varchar(255) NOT NULL,
	`message` text NOT NULL,
	`status` enum('Sent','Failed') NOT NULL DEFAULT 'Sent',
	`sent_date` datetime NOT NULL DEFAULT current_timestamp(),
	PRIMARY KEY (`notification_id`),
	KEY `idx_notifications_agent_id` (`agent_id`),
	KEY `idx_notifications_vehicle_id` (`vehicle_id`),
	KEY `idx_notifications_sent_date` (`sent_date`),
	CONSTRAINT `fk_notifications_agent` FOREIGN KEY (`agent_id`) REFERENCES `agents` (`agent_id`) ON DELETE CASCADE,
	CONSTRAINT `fk_notifications_vehicle` FOREIGN KEY (`vehicle_id`) REFERENCES `vehicles` (`vehicle_id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

INSERT INTO `agents` (`agent_id`, `name`, `username`, `password`, `created_at`) VALUES
(1, 'jyoshika', 'jyo', '0703', '2026-07-14 08:02:06'),(2, 'aravind', 'aravind', '0703', '2026-07-14 08:02:06');

INSERT INTO `customers` (`customer_id`, `agent_id`, `customer_name`, `phone`, `email`, `address`, `created_at`) VALUES
(1, 1, 'Vignesh Kumar', '+91 98765 43210', 'vignesh.kumar@example.com', '12 Anna Salai, Chennai, Tamil Nadu 600002', '2026-07-14 08:02:06'),
(2, 1, 'Priya Lakshmi', '+91 98765 43211', 'priya.lakshmi@example.com', '45 Avinashi Road, Coimbatore, Tamil Nadu 641018', '2026-07-14 08:02:06'),
(3, 1, 'Raj', '+91 98765 43212', 'karthik.raj@example.com', '78 KK Nagar, Madurai, Tamil Nadu 625020', '2026-07-14 08:02:06'),
(4, 1, 'Meena Devi', '+91 98765 43213', 'meena.devi@example.com', '23 Cantonment Road, Tiruchirappalli, Tamil Nadu 620001', '2026-07-14 08:02:07');

INSERT INTO `vehicles` (`vehicle_id`, `agent_id`, `customer_id`, `vehicle_type`, `vehicle_model`, `vehicle_number`, `insurance_company`, `policy_number`, `premium_amount`, `policy_expiry`, `renewal_date`, `status`, `renewed`, `created_at`) VALUES
(1, 1, 1, 'Car', 'Maruti Suzuki Baleno', 'TN-01-AB-1234', 'ICICI Lombard', 'IC-POL-1002', 1250.00, '2026-07-26', '2026-07-14', 'Active', 'No', '2026-07-14 08:02:07'),
(2, 1, 2, 'Motorcycle', 'Royal Enfield Classic 350', 'TN-38-CD-5678', 'HDFC ERGO', 'HE-POL-3482', 450.00, '2026-08-28', '2026-07-14', 'Active', 'No', '2026-07-14 08:02:07'),
(3, 1, 3, 'Truck', 'Tata Yodha Pickup', 'TN-58-EF-9012', 'Bajaj Allianz', 'BA-POL-9901', 1890.00, '2027-07-14', '2026-07-14', 'Active', 'Yes', '2026-07-14 08:02:07'),
(4, 1, 4, 'SUV', 'Hyundai Creta', 'TN-45-GH-3456', 'New India Assurance', 'NI-POL-7711', 890.00, '2026-10-12', '2026-07-14', 'Active', 'No', '2026-07-14 08:02:07');

INSERT INTO `renewal_history` (`history_id`, `vehicle_id`, `policy_number`, `premium_amount`, `old_expiry_date`, `new_expiry_date`, `renewal_date`, `agent_id`, `created_at`) VALUES
(1, 3, 'BA-POL-9901', 1890.00, '2026-06-29', '2027-07-14', '2026-07-14', 1, '2026-07-14 08:04:11');

INSERT INTO `notifications` (`notification_id`, `agent_id`, `vehicle_id`, `customer_name`, `email`, `subject`, `message`, `status`, `sent_date`) VALUES
(1, 1, 3, 'Karthik Raj', 'raj@example.com', 'Vehicle Insurance Policy Renewed', 'Your vehicle insurance policy has been renewed successfully.', 'Sent', '2026-07-14 08:04:11');

ALTER TABLE `agents` AUTO_INCREMENT = 2;
ALTER TABLE `customers` AUTO_INCREMENT = 5;
ALTER TABLE `vehicles` AUTO_INCREMENT = 5;
ALTER TABLE `renewal_history` AUTO_INCREMENT = 2;
ALTER TABLE `notifications` AUTO_INCREMENT = 2;

SET FOREIGN_KEY_CHECKS = 1;


-- add separately
USE vehicle_insurance;

INSERT INTO customers
(customer_id, agent_id, customer_name, phone, email, address)
VALUES
(5, 2, 'Suresh Kumar', '+91 98765 54321',
 'suresh.kumar@example.com',
 '18 Mount Road, Chennai, Tamil Nadu 600006'),

(6, 2, 'Anitha Rani', '+91 98765 54322',
 'anitha.rani@example.com',
 '42 Trichy Road, Coimbatore, Tamil Nadu 641045');

INSERT INTO vehicles
(vehicle_id, agent_id, customer_id, vehicle_type, vehicle_model,
 vehicle_number, insurance_company, policy_number, premium_amount,
 policy_expiry, renewal_date, status, renewed)
VALUES
(5, 2, 5, 'Car', 'Hyundai i20', 'TN-09-JK-7890',
 'Tata AIG', 'TA-POL-2205', 1150.00,
 '2027-03-15', '2026-08-24', 'Active', 'Yes'),

(6, 2, 6, 'SUV', 'Mahindra XUV700', 'TN-37-LM-2468',
 'United India Insurance', 'UI-POL-2206', 1750.00,
 '2027-05-20', NULL, 'Active', 'No');

INSERT INTO renewal_history
(history_id, vehicle_id, policy_number, premium_amount,
 old_expiry_date, new_expiry_date, renewal_date, agent_id)
VALUES
(2, 5, 'TA-POL-2205', 1150.00,
 '2026-08-15', '2027-03-15', '2026-08-24', 2);

INSERT INTO notifications
(notification_id, agent_id, vehicle_id, customer_name, email,
 subject, message, status, sent_date)
VALUES
(2, 2, 5, 'Suresh Kumar', 'suresh.kumar@example.com',
 'Vehicle Insurance Policy Renewed',
 'Your vehicle insurance policy has been renewed successfully.',
 'Sent', '2026-08-24 10:00:00');

ALTER TABLE customers AUTO_INCREMENT = 7;
ALTER TABLE vehicles AUTO_INCREMENT = 7;
ALTER TABLE renewal_history AUTO_INCREMENT = 3;
ALTER TABLE notifications AUTO_INCREMENT = 3;
ALTER TABLE agents AUTO_INCREMENT = 3;