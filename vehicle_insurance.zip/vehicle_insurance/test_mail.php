<?php

include("config/mail.php");

$result = sendRenewalMail(

"randomca777@gmail.com",

"Test Customer",

"TN34AB1234",

"Car",

"Hyundai i20",

"HDFC ERGO",

"POL123456",

5500,

date("d-m-Y"),

date("d-m-Y", strtotime("+1 year"))

);

if($result)
{
    echo "Email Sent Successfully";
}
else
{
    echo "Email Sending Failed";
}