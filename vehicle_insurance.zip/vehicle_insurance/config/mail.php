<?php

use PHPMailer\PHPMailer\PHPMailer;
use PHPMailer\PHPMailer\Exception;

require __DIR__ . '/../vendor/autoload.php';

function sendRenewalMail(
    $toEmail,
    $customerName,
    $vehicleNumber,
    $vehicleType,
    $vehicleModel,
    $insuranceCompany,
    $policyNumber,
    $premiumAmount,
    $renewalDate,
    $newExpiryDate
)
{
    $mail = new PHPMailer(true);

    try {

        // SMTP Settings
        $mail->isSMTP();
        $mail->Host       = 'smtp.gmail.com';
        $mail->SMTPAuth   = true;
        $mail->Username   = ''; // replace with your Gmail address
        $mail->Password   = '';   // replace with your Gmail App Password
        $mail->SMTPSecure = PHPMailer::ENCRYPTION_STARTTLS;
        $mail->Port       = 587;

        // Sender
        $mail->setFrom('22uca116@vcw.ac.in', 'RenewalNotice');

        // Receiver
        $mail->addAddress($toEmail, $customerName);

        // Email
        $mail->isHTML(true);
        $mail->Subject = 'Vehicle Insurance Policy Renewed Successfully';

        $mail->Body = "
        <h2>Vehicle Insurance Renewal System</h2>

        <p>Dear <b>$customerName</b>,</p>

        <p>Your vehicle insurance policy has been <b>renewed successfully.</b></p>

        <table border='1' cellpadding='8' cellspacing='0' style='border-collapse:collapse;'>

        <tr><td><b>Vehicle Number</b></td><td>$vehicleNumber</td></tr>

        <tr><td><b>Vehicle Type</b></td><td>$vehicleType</td></tr>

        <tr><td><b>Vehicle Model</b></td><td>$vehicleModel</td></tr>

        <tr><td><b>Insurance Company</b></td><td>$insuranceCompany</td></tr>

        <tr><td><b>Policy Number</b></td><td>$policyNumber</td></tr>

        <tr><td><b>Premium Amount</b></td><td>₹".number_format($premiumAmount,2)."</td></tr>

        <tr><td><b>Renewal Date</b></td><td>$renewalDate</td></tr>

        <tr><td><b>New Expiry Date</b></td><td>$newExpiryDate</td></tr>

        </table>

        <br>

        <p>Please keep this email for your records.</p>

        <p>Thank you for choosing our insurance renewal service.</p>

        <br>

        <b>Vehicle Insurance Renewal System</b>
        ";

       if ($mail->send()) {
    echo "Mail sent successfully.<br>";
    return true;
} else {
    echo "Send failed.<br>";
    return false;
}

    } 
    catch (Exception $e) {
    die("Mailer Error: " . $mail->ErrorInfo);
}

}