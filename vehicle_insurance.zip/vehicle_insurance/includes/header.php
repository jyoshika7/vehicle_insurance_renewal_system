<!DOCTYPE html>
<html>
<head>

<meta charset="UTF-8">

<title>Vehicle Insurance Renewal System</title>

<link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet">

<link rel="stylesheet"
href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.2/css/all.min.css">

<link rel="stylesheet"
href="/vehicle_insurance/assets/css/style.css">

</head>

<body>