<?php

function getStatus($expiryDate)
{
    $today = new DateTime();
    $expiry = new DateTime($expiryDate);

    $days = $today->diff($expiry)->days;

    if ($expiry < $today)
    {
        return "Expired";
    }
    elseif ($days <= 30)
    {
        return "Expiring Soon";
    }
    else
    {
        return "Active";
    }
}

function getDaysLeft($expiryDate)
{
    $today = new DateTime();
    $expiry = new DateTime($expiryDate);

    if ($expiry < $today)
    {
        return -($today->diff($expiry)->days);
    }

    return $today->diff($expiry)->days;
}

?>