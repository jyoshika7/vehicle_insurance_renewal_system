<?php
$current_page = basename($_SERVER['PHP_SELF']);
?>

<!-- Font Awesome -->
<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.2/css/all.min.css">

<style>

.sidebar{
    position:fixed;
    top:0;
    left:0;
    width:250px;
    height:100vh;
    background: linear-gradient(180deg, #0f172a 0%, #111827 100%);
    color:#fff;
    overflow-y:auto;
    z-index:1000;
    box-shadow: 8px 0 22px rgba(2, 6, 23, 0.25);
    border-right: 1px solid rgba(148, 163, 184, 0.15);
}

.sidebar-header{
    padding:25px 15px 18px;
    text-align:center;
    border-bottom:1px solid rgba(255,255,255,.12);
    background: linear-gradient(90deg, rgba(13,110,253,0.16), rgba(30,136,255,0.08));
}

.sidebar-header i{
    font-size:38px;
    color:#ffffff;
}

.sidebar-header h3{
    margin-top:10px;
    font-weight:bold;
    color:#f8fafc;
}

.sidebar .nav{
    padding:15px 0;
}

.sidebar .nav-link{
    color:#e2e8f0;
    padding:14px 20px;
    margin:4px 10px;
    border-radius:10px;
    display:flex;
    align-items:center;
    text-decoration:none;
    transition:.25s ease;
    font-weight:600;
}

.sidebar .nav-link i{
    width:30px;
    font-size:18px;
}

.sidebar .nav-link:hover{
    background: linear-gradient(90deg, #0d6efd, #1e88ff);
    color:#fff;
    box-shadow: 0 8px 18px rgba(13, 110, 253, 0.2);
}

.sidebar .nav-link.active{
    background: linear-gradient(90deg, #0d6efd, #1e88ff);
    color:#fff;
    font-weight:bold;
    box-shadow: 0 8px 18px rgba(13, 110, 253, 0.2);
}

.logout{
    color:#ffc9c9 !important;
}

.logout:hover{
    background: linear-gradient(90deg, #ef4444, #dc2626) !important;
    color:#fff !important;
}

</style>

<div class="sidebar">

    <div class="sidebar-header">

        <i class="fa-solid fa-shield-halved"></i>

        <h3>Insurance Agent</h3>

    </div>

    <div class="nav flex-column">

        <a href="dashboard.php"
           class="nav-link <?php echo ($current_page=='dashboard.php') ? 'active' : ''; ?>">
            <i class="fa-solid fa-gauge"></i>
            Dashboard
        </a>

        <a href="customers.php"
           class="nav-link <?php echo ($current_page=='customers.php' || $current_page=='add_customer.php' || $current_page=='edit_customer.php') ? 'active' : ''; ?>">
            <i class="fa-solid fa-users"></i>
            Customer Management
        </a>

        <a href="vehicles.php"
           class="nav-link <?php echo ($current_page=='vehicles.php' || $current_page=='add_vehicle.php' || $current_page=='edit_vehicle.php') ? 'active' : ''; ?>">
            <i class="fa-solid fa-car"></i>
            Vehicle Management
        </a>

        <a href="renewals.php"
           class="nav-link <?php echo ($current_page=='renewals.php' || $current_page=='renew_vehicle.php' || $current_page=='renew_policy.php') ? 'active' : ''; ?>">
            <i class="fa-solid fa-rotate"></i>
            Renew Policies
        </a>

        <a href="notification.php"
           class="nav-link <?php echo ($current_page=='notification.php') ? 'active' : ''; ?>">
            <i class="fa-solid fa-bell"></i>
            Notifications
        </a>

        <a href="reports.php"
           class="nav-link <?php echo ($current_page=='reports.php' || $current_page=='export_pdf.php' || $current_page=='export_excel.php') ? 'active' : ''; ?>">
            <i class="fa-solid fa-chart-column"></i>
            Reports
        </a>

        <a href="my_account.php"
           class="nav-link <?php echo ($current_page=='my_account.php') ? 'active' : ''; ?>">
            <i class="fa-solid fa-user-gear"></i>
            My Account
        </a>

        <hr style="border-color:rgba(255,255,255,.15);">

        <a href="logout.php" class="nav-link logout">
            <i class="fa-solid fa-right-from-bracket"></i>
            Logout
        </a>

    </div>

</div>