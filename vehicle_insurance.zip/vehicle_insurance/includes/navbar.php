<?php
$loggedAgents = $_SESSION['logged_agents'] ?? [];
?>

<nav class="navbar navbar-expand-lg bg-white shadow-sm px-4">

    <div class="container-fluid">

        <h4 class="mb-0">
            Vehicle Insurance Renewal System
        </h4>

        <div class="ms-auto d-flex align-items-center gap-3 flex-wrap">

            <span>

                <i class="fa-solid fa-calendar-days"></i>

                <?php echo date("d M Y"); ?>

            </span>

            <span>

                <i class="fa-solid fa-user"></i>

                <?php echo $_SESSION['agent_name']; ?>

            </span>

            <?php if (!empty($loggedAgents) && count($loggedAgents) > 1): ?>
                <div class="d-flex align-items-center gap-2 flex-wrap">
                    <?php foreach ($loggedAgents as $loggedAgent): ?>
                        <a href="../agent/switch_agent.php?agent_id=<?php echo $loggedAgent['agent_id']; ?>"
                           class="btn btn-sm <?php echo ($loggedAgent['agent_id'] == $_SESSION['agent_id']) ? 'btn-primary' : 'btn-outline-secondary'; ?>">
                            <?php echo htmlspecialchars($loggedAgent['name']); ?>
                        </a>
                    <?php endforeach; ?>
                </div>
            <?php endif; ?>

        </div>

    </div>

</nav>