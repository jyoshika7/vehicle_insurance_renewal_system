<?php
session_start();
?>

<!DOCTYPE html>
<html>
<head>

<title>Vehicle Insurance Renewal System</title>

<link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet">

<style>

body{
    background: linear-gradient(rgba(15, 23, 42, 0.65), rgba(15, 23, 42, 0.75)),
                url('https://images.unsplash.com/photo-1493238792000-8113da705763?auto=format&fit=crop&w=1600&q=80') center/cover no-repeat fixed;
    min-height: 100vh;
    display: flex;
    align-items: center;
    justify-content: center;
}

.login-container{
    width: 600px;
}

.card{
    border-radius: 15px;
    box-shadow: 0 10px 40px rgba(0,0,0,0.3);
    border: none;
}

.card-header{
    border-radius: 15px 15px 0 0 !important;
    padding: 40px 20px;
    text-align: center;
}

.card-header h1{
    font-weight: bold;
    margin-bottom: 10px;
}

.login-options{
    display: grid;
    grid-template-columns: 1fr 1fr;
    gap: 20px;
    padding: 40px;
}

.login-option{
    text-align: center;
    text-decoration: none;
    color: inherit;
    transition: transform 0.3s;
}

.login-option.full-width {
    grid-column: 1 / -1;
}

.login-option:hover{
    transform: translateY(-5px);
}

.option-card{
    background: white;
    border-radius: 12px;
    padding: 30px;
    box-shadow: 0 5px 15px rgba(0,0,0,0.1);
    border: 2px solid #f0f0f0;
    transition: all 0.3s;
}

.option-card:hover{
    border-color: #667eea;
    box-shadow: 0 10px 25px rgba(102, 126, 234, 0.2);
}

.option-icon{
    font-size: 50px;
    margin-bottom: 15px;
    color: #667eea;
}

.option-title{
    font-size: 20px;
    font-weight: bold;
    margin-bottom: 10px;
    color: #333;
}

.option-description{
    font-size: 14px;
    color: #666;
}

@media (max-width: 768px) {
    .login-container {
        width: 100%;
        margin: 20px;
    }
    
    .login-options {
        grid-template-columns: 1fr;
    }
}

</style>

</head>

<body>

<div class="login-container">

<div class="card">

<div class="card-header bg-primary text-white">

<h1><i class="fa-solid fa-car"></i> Vehicle Insurance</h1>
<p class="mb-0">Renewal Management System</p>

</div>

<div class="login-options">

<a href="login.php" class="login-option">
<div class="option-card">
<div class="option-icon">
<i class="fa-solid fa-user-tie"></i>
</div>

<div class="option-title">Agent Login</div>
<div class="option-description">Manage customers and policies</div>
</div>
</a>

<a href="register.php" class="login-option">
<div class="option-card">
<div class="option-icon">
<i class="fa-solid fa-user-plus"></i>
</div>
<div class="option-title">Agent Signup</div>
<div class="option-description">Create a new agent account</div>
</div>
</a>


</div>

</div>

</div>

<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.2/css/all.min.css">

<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/js/bootstrap.bundle.min.js"></script>

</body>

</html>
