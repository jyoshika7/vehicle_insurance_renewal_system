<?php
session_start();
include("config/db.php");

$error = "";
$success = "";

if (isset($_POST['register'])) {
    $name = mysqli_real_escape_string($conn, trim($_POST['name']));
    $username = mysqli_real_escape_string($conn, trim($_POST['username']));
    $password = mysqli_real_escape_string($conn, $_POST['password']);
    $confirmPassword = mysqli_real_escape_string($conn, $_POST['confirm_password']);

    if (empty($name) || empty($username) || empty($password)) {
        $error = "Please fill in all the fields.";
    } elseif ($password !== $confirmPassword) {
        $error = "Passwords do not match.";
    } else {
        $checkQuery = "SELECT * FROM agents WHERE username='$username'";
        $checkResult = mysqli_query($conn, $checkQuery);

        if (mysqli_num_rows($checkResult) > 0) {
            $error = "This username is already taken. Please choose another one.";
        } else {
            $insertQuery = "INSERT INTO agents (name, username, password) VALUES ('$name', '$username', '$password')";
            if (mysqli_query($conn, $insertQuery)) {
                $agentId = mysqli_insert_id($conn);

                $defaultCustomerQuery = "UPDATE customers SET agent_id = '$agentId' WHERE customer_id = 0";
                mysqli_query($conn, $defaultCustomerQuery);

                if (!isset($_SESSION['logged_agents']) || !is_array($_SESSION['logged_agents'])) {
                    $_SESSION['logged_agents'] = [];
                }

                $_SESSION['logged_agents'][$agentId] = [
                    'agent_id' => $agentId,
                    'name' => $name,
                    'username' => $username
                ];

                $_SESSION['agent_id'] = $agentId;
                $_SESSION['agent_name'] = $name;

                header("Location: agent/dashboard.php");
                exit();
            } else {
                $error = "Registration failed. Please try again.";
            }
        }
    }
}
?>

<!DOCTYPE html>
<html>
<head>
    <title>Agent Sign Up</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet">
    <style>
        body {
            background: linear-gradient(rgba(15, 23, 42, 0.6), rgba(15, 23, 42, 0.7)),
                        url('https://images.unsplash.com/photo-1553440569-bcc63803a83d?auto=format&fit=crop&w=1600&q=80') center/cover no-repeat fixed;
            min-height: 100vh;
            display: flex;
            align-items: center;
            justify-content: center;
        }

        .login-box {
            width: 420px;
            margin: 80px auto;
        }

        .card {
            border-radius: 10px;
        }
    </style>
</head>
<body>

<div class="login-box">
    <div class="card shadow">
        <div class="card-header bg-success text-white text-center">
            <h3>Vehicle Insurance Renewal System</h3>
            <h5>Agent Signup</h5>
        </div>

        <div class="card-body">
            <?php if ($error != "") { ?>
                <div class="alert alert-danger"><?php echo $error; ?></div>
            <?php } ?>

            <form method="POST">
                <div class="mb-3">
                    <label>Full Name</label>
                    <input type="text" name="name" class="form-control" required>
                </div>

                <div class="mb-3">
                    <label>Username</label>
                    <input type="text" name="username" class="form-control" required>
                </div>

                <div class="mb-3">
                    <label>Password</label>
                    <input type="password" name="password" class="form-control" required>
                </div>

                <div class="mb-3">
                    <label>Confirm Password</label>
                    <input type="password" name="confirm_password" class="form-control" required>
                </div>

                <div class="d-grid">
                    <button type="submit" name="register" class="btn btn-success">Create Account</button>
                </div>
            </form>

            <div class="mt-3 text-center">
                <a href="login.php">Already have an account? Login</a>
            </div>
        </div>
    </div>
</div>

</body>
</html>
