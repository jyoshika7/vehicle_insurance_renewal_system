<?php
session_start();
include("config/db.php");

$error = "";

if (isset($_POST['switch_agent'])) {
    $agentId = (int) $_POST['agent_id'];

    if (isset($_SESSION['logged_agents']) && is_array($_SESSION['logged_agents']) && isset($_SESSION['logged_agents'][$agentId])) {
        $_SESSION['agent_id'] = $agentId;
        $_SESSION['agent_name'] = $_SESSION['logged_agents'][$agentId]['name'];
        header("Location: agent/dashboard.php");
        exit();
    }

    $error = "Selected agent session not found.";
}

if(isset($_POST['login']))
{
    $username = mysqli_real_escape_string($conn,$_POST['username']);
    $password = mysqli_real_escape_string($conn,$_POST['password']);

    $query = "SELECT * FROM agents WHERE username='$username' AND password='$password'";
    $result = mysqli_query($conn,$query);

    if(mysqli_num_rows($result)==1)
    {
        $row = mysqli_fetch_assoc($result);

        if (!isset($_SESSION['logged_agents']) || !is_array($_SESSION['logged_agents'])) {
            $_SESSION['logged_agents'] = [];
        }

        $_SESSION['logged_agents'][$row['agent_id']] = [
            'agent_id' => $row['agent_id'],
            'name' => $row['name'],
            'username' => $row['username']
        ];

        $_SESSION['agent_id'] = $row['agent_id'];
        $_SESSION['agent_name'] = $row['name'];

        header("Location: agent/dashboard.php");
        exit();
    }
    else
    {
        $error = "Invalid Username or Password!";
    }
}

$loggedAgents = $_SESSION['logged_agents'] ?? [];
?>

<!DOCTYPE html>
<html>
<head>

<title>Agent Login</title>

<link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet">

<style>

body{
    background: linear-gradient(rgba(15, 23, 42, 0.6), rgba(15, 23, 42, 0.7)),
                url('https://images.unsplash.com/photo-1553440569-bcc63803a83d?auto=format&fit=crop&w=1600&q=80') center/cover no-repeat fixed;
    min-height: 100vh;
    display: flex;
    align-items: center;
    justify-content: center;
}

.login-box{
    width:400px;
    margin:80px auto;
}

.card{
    border-radius:10px;
}

</style>

</head>

<body>

<div class="login-box">

<div class="card shadow">

<div class="card-header bg-primary text-white text-center">

<h3>Vehicle Insurance Renewal System</h3>

<h5>Agent Login</h5>

</div>

<div class="card-body">

<?php
if($error!="")
{
?>
<div class="alert alert-danger">
<?php echo $error; ?>
</div>
<?php
}
?>

<?php if (!empty($loggedAgents)): ?>
<div class="mb-3">
    <form method="POST">
        <label class="form-label">Select active agent</label>
        <select name="agent_id" class="form-select mb-2" required>
            <option value="">Choose agent</option>
            <?php foreach ($loggedAgents as $agent): ?>
                <option value="<?php echo $agent['agent_id']; ?>"
                    <?php echo (($agent['agent_id'] == ($_SESSION['agent_id'] ?? 0)) ? 'selected' : ''); ?>>
                    <?php echo htmlspecialchars($agent['name']); ?>
                </option>
            <?php endforeach; ?>
        </select>
        <button type="submit" name="switch_agent" class="btn btn-outline-secondary w-100">Switch Agent</button>
    </form>
</div>
<?php endif; ?>

<form method="POST">

<div class="mb-3">

<label>Username</label>

<input
type="text"
name="username"
class="form-control"
required>

</div>

<div class="mb-3">

<label>Password</label>

<input
type="password"
name="password"
class="form-control"
required>

</div>

<div class="d-grid mb-3">

<button
type="submit"
name="login"
class="btn btn-primary">

Login

</button>

</div>

<div class="text-center">
    <a href="register.php">Create new agent account</a>
</div>

</form>

</div>

</div>

</div>

</body>

</html>